package com.example.qlsv;

public class CourseModal {

    private String Ma_mon;
    private String Ten_mon;
    private String So_tin_chi;
    private String So_ly_thuyet;
    private String So_thuc_hanh;

    public String getMa_mon() {
        return Ma_mon;
    }

    public void setMa_mon(String ma_mon) {
        this.Ma_mon = ma_mon;
    }


    public String getTen_mon() {
        return Ten_mon;
    }

    public void setTen_mon(String ten_mon) {
        this.Ten_mon = ten_mon;
    }

    public String getSo_tin_chi() {
        return So_tin_chi;
    }

    public void setSo_tin_chi(String so_tin_chi) {
        this.So_tin_chi = so_tin_chi;
    }

    public String getSo_ly_thuyet() {
        return So_ly_thuyet;
    }

    public void setSo_ly_thuyet(String so_ly_thuyet) {
        this.So_ly_thuyet = so_ly_thuyet;
    }

    public String getSo_thuc_hanh() {
        return So_thuc_hanh;
    }

    public void setSo_thuc_hanh(String so_thuc_hanh) {
        this.So_thuc_hanh = so_thuc_hanh;
    }

    public CourseModal(String Ma_mon, String Ten_mon, String So_tin_chi, String So_ly_thuyet, String So_thuc_hanh) {
        this.Ma_mon = Ma_mon;
        this.Ten_mon = Ten_mon;
        this.So_tin_chi = So_tin_chi;
        this.So_ly_thuyet = So_ly_thuyet;
        this.So_thuc_hanh = So_thuc_hanh;
    }
}
