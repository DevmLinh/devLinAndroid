package com.example.qlsv;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;

import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {

    private static final String DB_NAME = "QLSV";

    private static final int DB_VERSION = 1;

    private static final String TABLE_NAME = "MonHoc";

    private static final String MA_MON_COL = "Ma_Mon";

    private static final String TEN_MON_COL = "Ten_Mon";

    private static final String SO_TIN_CHI_COL = "So_tin_chi";

    private static final String SO_LY_THUYET_COL = "So_tiet_ly_thuyet";

    private static final String SO_THUC_HANH_COL = "So_tiet_thuc_hanh";


    public DBHandler(Context context){
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + MA_MON_COL + " TEXT PRIMARY KEY, "
                + TEN_MON_COL + " TEXT, "
                + SO_TIN_CHI_COL + " TEXT, "
                + SO_LY_THUYET_COL + " TEXT, "
                + SO_THUC_HANH_COL + " TEXT)";

        db.execSQL(query);
    }

    public void addNewCourse(String Ma_mon, String Ten_mon, String So_tin_chi, String So_ly_thuyet, String So_thuc_hanh) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(MA_MON_COL, Ma_mon);
        values.put(TEN_MON_COL, Ten_mon);
        values.put(SO_TIN_CHI_COL, So_tin_chi);
        values.put(SO_LY_THUYET_COL, So_ly_thuyet);
        values.put(SO_THUC_HANH_COL, So_thuc_hanh);

        db.insert(TABLE_NAME, null, values);

        db.close();
    }

    public ArrayList<CourseModal> readCourse() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursorCourse = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        ArrayList<CourseModal> courseModalArrayList = new ArrayList<>();

        if(cursorCourse.moveToFirst()) {
            do {
                courseModalArrayList.add(new CourseModal(
                        cursorCourse.getString(0),
                        cursorCourse.getString(1),
                        cursorCourse.getString(2),
                        cursorCourse.getString(3),
                        cursorCourse.getString(4)));
            } while (cursorCourse.moveToNext());
        }

        cursorCourse.close();

        return courseModalArrayList;
    }

    // below is the method for updating our courses
    public void updateCourse(String originalMaMon, String maMon, String tenMon,
                             String tinChi, String lyThuyet, String thucHanh) {

        // calling a method to get writable database.
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        // on below line we are passing all values
        // along with its key and value pair.
        values.put(MA_MON_COL, maMon);
        values.put(TEN_MON_COL, tenMon);
        values.put(SO_TIN_CHI_COL, tinChi);
        values.put(SO_LY_THUYET_COL, lyThuyet);
        values.put(SO_THUC_HANH_COL, thucHanh);

        // on below line we are calling a update method to update our database and passing our values.
        // and we are comparing it with name of our course which is stored in original name variable.
        db.update(TABLE_NAME, values, "Ma_Mon=?", new String[]{originalMaMon});
        db.close();
    }

    // below is the method for deleting our course.
    public void deleteCourse(String maMon) {
        // on below line we are creating
        // a variable to write our database.
        SQLiteDatabase db = this.getWritableDatabase();

        // on below line we are calling a method to delete our
        // course and we are comparing it with our course name.
        db.delete(TABLE_NAME, "Ma_Mon=?", new String[]{maMon});
        db.close();
    }





    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}
