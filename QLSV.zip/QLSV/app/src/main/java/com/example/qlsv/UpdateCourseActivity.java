package com.example.qlsv;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateCourseActivity extends AppCompatActivity {
    private EditText edtMaMon, edtTenMon, edtSoTinChi, edtSoLyThuyet, edtSoThucHanh;
    private Button btnUpdateCourse, btnDeleteCourse;
    private DBHandler dbHandler;
    String mamon1, tenmon1, tinchi1, lythuyet1, thuchanh1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_course);

        edtMaMon = findViewById(R.id.idEdtMaMon);
        edtTenMon = findViewById(R.id.idEdtTenMon);
        edtSoTinChi = findViewById(R.id.idEdtTinChi);
        edtSoLyThuyet = findViewById(R.id.idEdtLyThuyet);
        edtSoThucHanh = findViewById(R.id.idEdtThucHanh);
        btnUpdateCourse = findViewById(R.id.idBtnUpdateCourse);
        btnDeleteCourse = findViewById(R.id.idBtnDelete);

        dbHandler = new DBHandler(UpdateCourseActivity.this);
        Intent intent = this.getIntent();

        mamon1 = intent.getStringExtra("Mamon");
        tenmon1 = intent.getStringExtra("Tenmon");
        tinchi1 = intent.getStringExtra("Sotinchi");
        lythuyet1 = intent.getStringExtra("Solythuyet");
        thuchanh1 = intent.getStringExtra("Sothuchanh");

        edtMaMon.setText(" " + mamon1);
        edtTenMon.setText(" " + tenmon1);
        edtSoTinChi.setText(" " + tinchi1);
        edtSoLyThuyet.setText(" " + lythuyet1);
        edtSoThucHanh.setText(" " + thuchanh1);

        btnUpdateCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbHandler.updateCourse(mamon1, edtMaMon.getText().toString(), edtTenMon.getText().toString(), edtSoTinChi.getText().toString(), edtSoLyThuyet.getText().toString(), edtSoThucHanh.getText().toString());

                Toast.makeText(UpdateCourseActivity.this, "Cập nhật thành công", Toast.LENGTH_SHORT).show();

                Intent i = new Intent(UpdateCourseActivity.this, MainActivity.class);
                startActivity(i);
            }
        });

        btnDeleteCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbHandler.deleteCourse(mamon1);

                Toast.makeText(UpdateCourseActivity.this, "Xóa thành công", Toast.LENGTH_SHORT).show();

                Intent i = new Intent(UpdateCourseActivity.this, MainActivity.class);
                startActivity(i);
            }
        });

    }
}