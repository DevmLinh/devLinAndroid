package com.example.quan_li_nhan_su;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.quan_li_nhan_su.Department.DepartmentModal;
import com.example.quan_li_nhan_su.Position.PositionModal;
import com.example.quan_li_nhan_su.Salary.SalaryModal;
import com.example.quan_li_nhan_su.Staff.StaffModal;
import com.example.quan_li_nhan_su.Time.TimeModal;
import com.example.quan_li_nhan_su.level.LevelModal;

import java.util.ArrayList;
import java.util.List;

public class DBHandler extends SQLiteOpenHelper {

    private static final String DB_NAME = "QLNS";

    private static final int DB_VERSION = 1;

    private static final String TABLE_DEPARTMENT = "Phong_Ban";

    private static final String MA_PB_COL = "Ma_phong_ban";

    private static final String TEN_PB_COL = "Ten_phong_ban";

    private static final String SDT_PB_COL = "So_dien_thoai";

    private static final String DIA_CHI_PB_COL = "Dia_chi";

//
    private static final String TABLE_LEVEL = "Trinh_Do";

    private static final String MA_TD_COL = "Ma_TD";

    private static final String TEN_TD_COL = "Ten_TD";

    private static final String CHUYEN_NGANH_COL = "Chuyen_Nganh";

//
    private static final String TABLE_SALARY = "He_So_Luong";

    private static final String BAC_LUONG_COL = "Bac_Luong";

    private static final String LUONG_CO_BAN_COL = "Luong_Co_Ban";

    private static final String HE_SO_LUONG_COL = "He_So_Luong";

    //
    private static final String TABLE_POSITION = "Chuc_vu";

    private static final String MA_CV_COL = "Ma_chuc_vu";

    private static final String TEN_CV_COL = "Ten_chuc_vu";

    private static final String HE_SO_PC_COL = "He_so_phu_cap";

    //
    private static final String TABLE_STAFF = "Nhan_vien";

    private static final String MA_NV_COL = "Ma_nhan_vien";

    private static final String TEN_NV_COL = "Ten_nhan_vien";

    private static final String NGAY_SINH_COL = "Ngay_sinh";

    private static final String NOI_SINH_COL = "Noi_sinh";

    private static final String GIOI_TINH_COL = "Gioi_tinh";

    private static final String DAN_TOC_COL = "Dan_toc";

    private static final String DIA_CHI_COL = "Dia_chi";

    private static final String DIEN_THOAI_COL = "Dien_thoai";

    private static final String QUE_QUAN_COL = "Que_quan";

    //
    private static final String TABLE_TIME = "Thoi_gian_nhan_chuc";

    private static final String NGAY_NC_COL = "Ngay_nhan_chuc";

    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_TABLE_DEPARTMENT = "CREATE TABLE " + TABLE_DEPARTMENT + " ( "
                + MA_PB_COL + " TEXT PRIMARY KEY, "
                + TEN_PB_COL + " TEXT, "
                + DIA_CHI_PB_COL + " TEXT, "
                + SDT_PB_COL + " TEXT)";

        String CREATE_TABLE_LV = "CREATE TABLE " + TABLE_LEVEL + " ( "
                + MA_TD_COL + " TEXT PRIMARY KEY, "
                + TEN_TD_COL + " TEXT, "
                + CHUYEN_NGANH_COL + " TEXT)";

        String CREATE_TABLE_SLR = "CREATE TABLE " + TABLE_SALARY + " ( "
                + BAC_LUONG_COL + " TEXT PRIMARY KEY, "
                + LUONG_CO_BAN_COL + " TEXT, "
                + HE_SO_LUONG_COL + " TEXT)";

        String CREATE_TABLE_POSITION = "CREATE TABLE " + TABLE_POSITION + " ( "
                + MA_CV_COL + " TEXT PRIMARY KEY, "
                + TEN_CV_COL + " TEXT, "
                + HE_SO_PC_COL + " TEXT)";

        String CREATE_TABLE_STAFF = "CREATE TABLE " + TABLE_STAFF + " ( "
                + MA_NV_COL + " TEXT PRIMARY KEY, "
                + TEN_NV_COL + " TEXT, "
                + NGAY_SINH_COL + " TEXT, "
                + NOI_SINH_COL + " TEXT, "
                + GIOI_TINH_COL + " TEXT, "
                + DAN_TOC_COL + " TEXT, "
                + DIA_CHI_COL + " TEXT, "
                + DIEN_THOAI_COL + " TEXT, "
                + QUE_QUAN_COL + " TEXT, "
                + MA_TD_COL + " TEXT, "
                + MA_CV_COL + " TEXT, "
                + MA_PB_COL + " TEXT, "
                + BAC_LUONG_COL + " TEXT, "
                + "FOREIGN KEY ( " + MA_TD_COL + " ) REFERENCES " + TABLE_LEVEL + " ( " + MA_TD_COL + " ), "
                + "FOREIGN KEY ( " + MA_CV_COL + " ) REFERENCES " + TABLE_POSITION + " ( " + MA_CV_COL + " ), "
                + "FOREIGN KEY ( " + MA_PB_COL + " ) REFERENCES " + TABLE_DEPARTMENT + " ( " + MA_PB_COL + " ), "
                + "FOREIGN KEY ( " + BAC_LUONG_COL + " ) REFERENCES " + TABLE_SALARY + " ( " + BAC_LUONG_COL + " ))";

        String CREATE_TABLE_TIME = "CREATE TABLE " + TABLE_TIME + " ( "
                + MA_NV_COL + " TEXT NOT NULL, "
                + MA_CV_COL + " TEXT NOT NULL, "
                + NGAY_NC_COL + " TEXT, "
                + " PRIMARY KEY ( " + MA_NV_COL + ", " + MA_CV_COL + " ), "
                + " FOREIGN KEY ( " + MA_NV_COL + " ) REFERENCES " + TABLE_STAFF + " ( " + MA_NV_COL + " ), "
                + " FOREIGN KEY ( " + MA_CV_COL + " ) REFERENCES " + TABLE_POSITION + " ( " + MA_CV_COL + " ))";

        db.execSQL(CREATE_TABLE_DEPARTMENT);
        db.execSQL(CREATE_TABLE_LV);
        db.execSQL(CREATE_TABLE_SLR);
        db.execSQL(CREATE_TABLE_POSITION);
        db.execSQL(CREATE_TABLE_STAFF);
        db.execSQL(CREATE_TABLE_TIME);
    }
// Thêm
    public void addDepartment(String MA_PB, String TEN_PB, String DIA_CHI, String SDT) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(MA_PB_COL, MA_PB);
        values.put(TEN_PB_COL, TEN_PB);
        values.put(DIA_CHI_PB_COL, DIA_CHI);
        values.put(SDT_PB_COL, SDT);

        db.insert(TABLE_DEPARTMENT, null, values);

        db.close();
    }


    public void addLevel(String MA_TD, String TEN_TD, String CHUYEN_NGANH) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(MA_TD_COL, MA_TD);
        values.put(TEN_TD_COL, TEN_TD);
        values.put(CHUYEN_NGANH_COL, CHUYEN_NGANH);

        db.insert(TABLE_LEVEL,null,values);
        db.close();
    }

    public void addSalary(String BAC_LUONG, String LUONG_CB, String HE_SO) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(BAC_LUONG_COL, BAC_LUONG);
        values.put(LUONG_CO_BAN_COL, LUONG_CB);
        values.put(HE_SO_LUONG_COL,HE_SO);

        db.insert(TABLE_SALARY,null,values);
        db.close();
    }

    public void addPosition(String MA_CV, String TEN_CV, String HE_SO_PC) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(MA_CV_COL, MA_CV);
        values.put(TEN_CV_COL, TEN_CV);
        values.put(HE_SO_PC_COL,HE_SO_PC);

        db.insert(TABLE_POSITION,null,values);
        db.close();
    }

    public void addStaff(String MA_NV, String TEN_NV, String NGAY_SINH, String NOI_SINH, String GIOI_TINH, String DAN_TOC, String DIA_CHI, String DIEN_THOAI, String QUE_QUAN, String MA_TD, String MA_CV, String MA_PB, String BAC_LUONG) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(MA_NV_COL, MA_NV);
        values.put(TEN_NV_COL, TEN_NV);
        values.put(NGAY_SINH_COL,NGAY_SINH);
        values.put(NOI_SINH_COL, NOI_SINH);
        values.put(GIOI_TINH_COL, GIOI_TINH);
        values.put(DAN_TOC_COL,DAN_TOC);
        values.put(DIA_CHI_COL, DIA_CHI);
        values.put(DIEN_THOAI_COL, DIEN_THOAI);
        values.put(QUE_QUAN_COL,QUE_QUAN);
        values.put(MA_TD_COL, MA_TD);
        values.put(MA_CV_COL, MA_CV);
        values.put(MA_PB_COL, MA_PB);
        values.put(BAC_LUONG_COL, BAC_LUONG);

        db.insert(TABLE_STAFF,null,values);
        db.close();
    }

    public void addTime(String MANV, String MACV, String NGAY_NC) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(MA_NV_COL, MANV);
        values.put(MA_CV_COL, MACV);
        values.put(NGAY_NC_COL,NGAY_NC);

        db.insert(TABLE_TIME,null,values);
        db.close();
    }
// Đọc
    public ArrayList<DepartmentModal> readDepartment() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_DEPARTMENT, null);

        ArrayList<DepartmentModal> Modals = new ArrayList<>();

        if(cursor.moveToFirst()) {
            do {
                Modals.add(new DepartmentModal(
                        cursor.getString(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3)
                ));
            } while (cursor.moveToNext());
        }

        cursor.close();

        return Modals;
    }


    public ArrayList<LevelModal> readLevel() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery("SELECT * FROM " + TABLE_LEVEL, null );

        ArrayList<LevelModal> Modals = new ArrayList<>();

        if (c.moveToFirst()) {
            do {
                Modals.add(new LevelModal(
                        c.getString(0),
                        c.getString(1),
                        c.getString(2)
                ));
            }while (c.moveToNext());
        }

        c.close();
        return Modals;
    }

    public ArrayList<SalaryModal> readSalary() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery("SELECT * FROM " + TABLE_SALARY, null);

        ArrayList<SalaryModal> Modals = new ArrayList<>();

        if (c.moveToFirst()) {
            do {
                Modals.add(new SalaryModal(
                        c.getString(0),
                        c.getString(1),
                        c.getString(2)
                ));
            } while (c.moveToNext());
        }

        c.close();
        return Modals;
    }

    public ArrayList<PositionModal> readPosition() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery("SELECT * FROM " + TABLE_POSITION, null);

        ArrayList<PositionModal> Modals = new ArrayList<>();

        if (c.moveToFirst()) {
            do {
                Modals.add(new PositionModal(
                        c.getString(0),
                        c.getString(1),
                        c.getString(2)
                ));
            } while (c.moveToNext());
        }

        c.close();
        return Modals;
    }

    public ArrayList<StaffModal> readStaff(String MaPB) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery("SELECT * FROM " + TABLE_STAFF + " WHERE " + MA_PB_COL + "=?", new String[] {MaPB});

        ArrayList<StaffModal> Modals = new ArrayList<>();

        if (c.moveToFirst()) {
            do {
                Modals.add(new StaffModal(
                        c.getString(0),
                        c.getString(1),
                        c.getString(2),
                        c.getString(3),
                        c.getString(4),
                        c.getString(5),
                        c.getString(6),
                        c.getString(7),
                        c.getString(8),
                        c.getString(9),
                        c.getString(10),
                        c.getString(11),
                        c.getString(12)
                ));
            } while (c.moveToNext());
        }

        c.close();
        return Modals;
    }

    public ArrayList<TimeModal> readTime(String manv, String macv) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery("SELECT * FROM " + TABLE_TIME + " WHERE " + MA_NV_COL + "=?" + " AND " + MA_CV_COL + "=?", new String[] {manv, macv});

        ArrayList<TimeModal> Modals = new ArrayList<>();

        if (c.moveToFirst()) {
            do {
                Modals.add(new TimeModal(
                        c.getString(0),
                        c.getString(1),
                        c.getString(2)
                ));
            } while (c.moveToNext());
        }

        c.close();
        return Modals;
    }

    public List<String> readAllMa(String TABLE_NAME) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursorClass = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        List<String> ModalArrayList = new ArrayList<String>();

        if(cursorClass.moveToFirst()) {
            do {
                ModalArrayList.add(cursorClass.getString(0));
            } while (cursorClass.moveToNext());
        }

        cursorClass.close();

        return ModalArrayList;
    }
//  Chỉnh Sửa
    public void updateDepartment(String originalMaPB, String MaPB, String TenPB,
                            String Diachi, String Sdt) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(MA_PB_COL, MaPB);
        values.put(TEN_PB_COL, TenPB);
        values.put(DIA_CHI_PB_COL, Diachi);
        values.put(SDT_PB_COL, Sdt);

        db.update(TABLE_DEPARTMENT, values, MA_PB_COL + "=?", new String[]{originalMaPB});
        db.close();
    }

    public void updateLevel(String originalMaTD, String MaTD, String TenTD, String ChuyenNganh) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(MA_TD_COL,MaTD);
        values.put(TEN_TD_COL,TenTD);
        values.put(CHUYEN_NGANH_COL,ChuyenNganh);

        db.update(TABLE_LEVEL,values,MA_TD_COL + "=?", new String[]{originalMaTD});
        db.close();
    }

    public void updateSalary(String originalBacLuong, String BacLuong, String LuongCB, String HsLuong) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(BAC_LUONG_COL,BacLuong);
        values.put(LUONG_CO_BAN_COL,LuongCB);
        values.put(HE_SO_LUONG_COL,HsLuong);

        db.update(TABLE_SALARY,values,BAC_LUONG_COL + "=?", new String[]{originalBacLuong});
        db.close();
    }

    public void updatePosition(String originalMaCV, String MaCV, String TenCv, String HSPC) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(MA_CV_COL,MaCV);
        values.put(TEN_CV_COL,TenCv);
        values.put(HE_SO_PC_COL,HSPC);

        db.update(TABLE_POSITION,values,MA_CV_COL + "=?", new String[]{originalMaCV});
        db.close();
    }

    public void updateStaff(String originalMaNV, String maNV, String tenNV, String ngaySinh, String noiSinh, String gioiTinh, String danToc, String diaChi, String dienThoai, String queQuan, String maTD, String maCV, String maPB, String bacLuong) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(MA_NV_COL, maNV);
        values.put(TEN_NV_COL, tenNV);
        values.put(NGAY_SINH_COL,ngaySinh);
        values.put(NOI_SINH_COL, noiSinh);
        values.put(GIOI_TINH_COL, gioiTinh);
        values.put(DAN_TOC_COL, danToc);
        values.put(DIA_CHI_COL, diaChi);
        values.put(DIEN_THOAI_COL, dienThoai);
        values.put(QUE_QUAN_COL, queQuan);
        values.put(MA_TD_COL, maTD);
        values.put(MA_CV_COL, maCV);
        values.put(MA_PB_COL, maPB);
        values.put(BAC_LUONG_COL, bacLuong);

        db.update(TABLE_STAFF,values,MA_NV_COL + "=?", new String[]{originalMaNV});
        db.close();
    }

    public void updateTime(String originalMaNV, String originalMaCV, String MANV, String MACV, String NGAYNC) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(MA_NV_COL, MANV);
        values.put(MA_CV_COL, MACV);
        values.put(NGAY_NC_COL, NGAYNC);

        db.update(TABLE_TIME,values,MA_NV_COL + "=?" + " AND " + MA_CV_COL + "=?", new String[]{originalMaNV, originalMaCV});
        db.close();
    }
//  Xóa
    public void deleteCourse(String originalMaPB) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_DEPARTMENT, MA_PB_COL + "=?", new String[]{originalMaPB});

        db.close();
    }

    public void deleteLevel(String orginalMaTD) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_LEVEL, MA_TD_COL + "=?" , new String[]{orginalMaTD});
        db.close();
    }

    public void deleteSalary(String orginalBacLuong) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_SALARY, BAC_LUONG_COL + "=?" , new String[]{orginalBacLuong});
        db.close();
    }

    public void deletePosition(String orginalMaCV) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_POSITION, MA_CV_COL + "=?" , new String[]{orginalMaCV});
        db.close();
    }

    public void deleteStaff(String orginalMaNV) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_STAFF, MA_NV_COL + "=?" , new String[]{orginalMaNV});
        db.close();
    }

    public void deleteTime(String orginalMaNV, String orginalMaCV) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_TIME, MA_NV_COL + "=?" + " AND " + MA_CV_COL + "=?" , new String[]{orginalMaNV, orginalMaCV});
        db.close();
    }

    //    check
    public boolean checkDP() {
        boolean check;
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery(" SELECT * FROM " + TABLE_DEPARTMENT, null);
        if ( c!= null && c.moveToFirst()) {
            check = false;
        } else {
            check = true;
        }
        c.close();
        return check;
    }

    public boolean checkLV() {
        boolean check;
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery(" SELECT * FROM " + TABLE_LEVEL, null);
        if ( c!= null && c.moveToFirst()) {
            check = false;
        } else {
            check = true;
        }
        c.close();
        return check;
    }

    public boolean check(String tablename) {
        boolean check;
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery(" SELECT * FROM " + tablename, null);
        if ( c!= null && c.moveToFirst()) {
            check = false;
        } else {
            check = true;
        }
        c.close();
        return check;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DEPARTMENT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LEVEL);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SALARY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_POSITION);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STAFF);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TIME);
        onCreate(db);
    }
}
