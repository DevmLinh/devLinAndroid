package com.example.quan_li_nhan_su.Department;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quan_li_nhan_su.DBHandler;
import com.example.quan_li_nhan_su.MainActivity;
import com.example.quan_li_nhan_su.R;

public class Department extends AppCompatActivity {
    private Button btnAdd, btnList;
    private DBHandler db;
    private TextView tvBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_department);

        btnAdd = findViewById(R.id.btnAddDepartment);
        btnList = findViewById(R.id.btnListDepartment);
        DBHandler db = new DBHandler(Department.this);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Department.this, MainActivity.class);
                startActivity(i);
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Department.this, addDepartment.class);
                startActivity(i);
            }
        });

        btnList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!db.checkDP()) {
                    Intent i = new Intent(Department.this, ViewDepartment.class);
                    startActivity(i);
                } else {
                    Intent i = new Intent(Department.this, addDepartment.class);
                    Toast.makeText(Department.this, "Danh sách rỗng, vui lòng nhập thông tin", Toast.LENGTH_SHORT).show();
                    startActivity(i);
                }
            }
        });
    }
}