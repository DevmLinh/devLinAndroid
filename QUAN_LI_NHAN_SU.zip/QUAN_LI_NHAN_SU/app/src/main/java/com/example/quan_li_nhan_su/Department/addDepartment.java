package com.example.quan_li_nhan_su.Department;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quan_li_nhan_su.DBHandler;
import com.example.quan_li_nhan_su.MainActivity;
import com.example.quan_li_nhan_su.R;

public class addDepartment extends AppCompatActivity {
    private EditText edtMaPB, edtTenPB, edtDiaChi, edtSdt;
    private Button btnAdd;
    String mapb, tenpb, diachi, sdt;
    TextView tvBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_department);

        DBHandler db = new DBHandler(addDepartment.this);

        edtMaPB = findViewById(R.id.idEdtMaTD);
        edtTenPB = findViewById(R.id.idEdtTenTD);
        edtDiaChi = findViewById(R.id.idEdtCN);
        edtSdt = findViewById(R.id.idEdtSdtPB);
        btnAdd = findViewById(R.id.idBtnAddDepartment);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(addDepartment.this, MainActivity.class);
                startActivity(i);
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mapb = edtMaPB.getText().toString();
                tenpb = edtTenPB.getText().toString();
                diachi = edtDiaChi.getText().toString();
                sdt = edtSdt.getText().toString();

                if(mapb.isEmpty() || tenpb.isEmpty() || diachi.isEmpty() || sdt.isEmpty()) {
                    Toast.makeText(addDepartment.this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                } else {
                    db.addDepartment(mapb, tenpb, diachi, sdt);
                    Toast.makeText(addDepartment.this, "Thêm thành công", Toast.LENGTH_SHORT).show();
                    clear();
                }
            }
        });
    }
    public void clear() {
        edtMaPB.setText("");
        edtDiaChi.setText("");
        edtTenPB.setText("");
        edtSdt.setText("");
        edtMaPB.requestFocus();
    }
}