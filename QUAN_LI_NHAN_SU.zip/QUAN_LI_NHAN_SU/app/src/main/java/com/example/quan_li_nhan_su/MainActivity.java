package com.example.quan_li_nhan_su;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;

import com.example.quan_li_nhan_su.Department.Department;
import com.example.quan_li_nhan_su.Position.Position;
import com.example.quan_li_nhan_su.Salary.Salary;
import com.example.quan_li_nhan_su.Staff.Staff;
import com.example.quan_li_nhan_su.Time.Time;
import com.example.quan_li_nhan_su.level.Level;

public class MainActivity extends AppCompatActivity {
    private CardView cardPB, cardNS, cardCV, cardTGNC, cardLuong, cardTD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cardPB = findViewById(R.id.cardPhongban);
        cardNS = findViewById(R.id.cardNhansu);
        cardCV = findViewById(R.id.cardChucVu);
        cardLuong = findViewById(R.id.cardLuong);
        cardTD = findViewById(R.id.cardTrinhDo);
        cardTGNC = findViewById(R.id.cardThoiGian);

        cardPB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, Department.class);
                startActivity(i);
            }
        });

        cardTD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, Level.class);
                startActivity(i);
            }
        });

        cardLuong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, Salary.class);
                startActivity(i);
            }
        });

        cardCV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, Position.class);
                startActivity(i);
            }
        });

        cardNS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, Staff.class);
                startActivity(i);
            }
        });

        cardTGNC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, Time.class);
                startActivity(i);
            }
        });
    }
}