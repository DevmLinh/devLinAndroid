package com.example.quan_li_nhan_su.Position;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.quan_li_nhan_su.R;

import java.util.ArrayList;

public class PositionRVAdapter extends RecyclerView.Adapter<PositionRVAdapter.ViewHolder> {

    private ArrayList<PositionModal> ModalArrayList;
    private Context context;

    public PositionRVAdapter(ArrayList<PositionModal> ModalArrayList, Context context) {
        this.ModalArrayList = ModalArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.position_rv_item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PositionModal modal = ModalArrayList.get(position);
        holder.Macv.setText("Mã chức vụ: " + modal.getMa_cv());
        holder.Tencv.setText("Tên chức vụ: " + modal.getTen_cv());
        holder.HesoPC.setText("Hệ số phụ cấp: " + modal.getHe_so_pc());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(context, UpdatePosition.class);

                // below we are passing all our values.
                i.putExtra("Macv", modal.getMa_cv());
                i.putExtra("Tencv", modal.getTen_cv());
                i.putExtra("Hesopc", modal.getHe_so_pc());

                // starting our activity.
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() { return ModalArrayList.size(); }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView Macv, Tencv, HesoPC;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            Macv = itemView.findViewById(R.id.tvMaNVTime);
            Tencv = itemView.findViewById(R.id.tvMaCVTime);
            HesoPC = itemView.findViewById(R.id.tvNgayNC);
        }
    }
}
