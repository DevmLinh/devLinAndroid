package com.example.quan_li_nhan_su.Position;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.example.quan_li_nhan_su.DBHandler;
import com.example.quan_li_nhan_su.Department.addDepartment;
import com.example.quan_li_nhan_su.MainActivity;
import com.example.quan_li_nhan_su.R;

import java.util.ArrayList;

public class ViewPosition extends AppCompatActivity {
    private ArrayList<PositionModal> ModalArrayList;
    private DBHandler dbHandler;
    private PositionRVAdapter RVAdapter;
    private RecyclerView recyclerView;
    private TextView tvBack;

    @Override
    protected void  onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_position);

        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ViewPosition.this, MainActivity.class);
                startActivity(i);
            }
        });

        ModalArrayList = new ArrayList<>();
        dbHandler = new DBHandler(ViewPosition.this);

        ModalArrayList = dbHandler.readPosition();

        RVAdapter = new PositionRVAdapter(ModalArrayList, ViewPosition.this);
        recyclerView = findViewById(R.id.idRVTime);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(ViewPosition.this, RecyclerView.VERTICAL,false);
        recyclerView.setLayoutManager(linearLayoutManager);

        recyclerView.setAdapter(RVAdapter);


    }
}
