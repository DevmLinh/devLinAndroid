package com.example.quan_li_nhan_su.Position;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quan_li_nhan_su.DBHandler;
import com.example.quan_li_nhan_su.Department.addDepartment;
import com.example.quan_li_nhan_su.MainActivity;
import com.example.quan_li_nhan_su.R;

public class addPosition extends AppCompatActivity {
    private EditText edtMACV, edtTENCV, edtHSPC;
    private Button btnAdd, btnBack, btnMenu;
    private TextView tvBack;
    String macv, tencv, hesoPC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_position);

        DBHandler db = new DBHandler(addPosition.this);

        edtMACV = findViewById(R.id.idEdtMaCV);
        edtTENCV = findViewById(R.id.idEdtTenCV);
        edtHSPC = findViewById(R.id.idEdtHeSoPC);
        btnAdd = findViewById(R.id.idBtnAddPosition);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(addPosition.this, MainActivity.class);
                startActivity(i);
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                macv = edtMACV.getText().toString();
                tencv = edtTENCV.getText().toString();
                hesoPC = edtHSPC.getText().toString();

                if (macv.isEmpty() || tencv.isEmpty() || hesoPC.isEmpty()) {
                    Toast.makeText(addPosition.this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                } else {
                    db.addPosition(macv, tencv, hesoPC);
                    Toast.makeText(addPosition.this, "Thêm thành công", Toast.LENGTH_SHORT).show();
                    clear();
                }
            }
        });
    }
    public void clear() {
        edtMACV.setText("");
        edtTENCV.setText("");
        edtHSPC.setText("");
        edtMACV.requestFocus();
    }
}
