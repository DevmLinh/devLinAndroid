package com.example.quan_li_nhan_su.Salary;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quan_li_nhan_su.DBHandler;
import com.example.quan_li_nhan_su.Department.addDepartment;
import com.example.quan_li_nhan_su.MainActivity;
import com.example.quan_li_nhan_su.R;

public class UpdateSalary extends AppCompatActivity {
    private EditText edtBL, edtLCB, edtHSL;
    private Button btnUpdate, btnDelete, btnBack, btnMenu;
    private DBHandler dbHandler;
    private String bacluong1, luongcd1, heso1;
    private TextView tvBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_salary);

        dbHandler = new DBHandler(UpdateSalary.this);

        edtBL = findViewById(R.id.idEdtUpdateBacLuong);
        edtLCB = findViewById(R.id.idEdtUpdateLuongCB);
        edtHSL = findViewById(R.id.idEdtUpdateHeSo);
        btnUpdate = findViewById(R.id.idBtnUpdateSalary);
        btnDelete = findViewById(R.id.idBtnDeleteSalary);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(UpdateSalary.this, MainActivity.class);
                startActivity(i);
            }
        });

        Intent intent = this.getIntent();

        bacluong1 = intent.getStringExtra("bacluong");
        luongcd1 = intent.getStringExtra("luongcb");
        heso1 = intent.getStringExtra("hsluong");

        edtBL.setText(" " + bacluong1);
        edtLCB.setText(" " + luongcd1);
        edtHSL.setText(" " + heso1);

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtBL.getText().toString().isEmpty() || edtLCB.getText().toString().isEmpty() || edtHSL.getText().toString().isEmpty()) {
                    Toast.makeText(UpdateSalary.this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                } else {
                    dbHandler.updateSalary(bacluong1, edtBL.getText().toString(), edtLCB.getText().toString(), edtHSL.getText().toString());
                    Toast.makeText(UpdateSalary.this, "Cập nhật thành công", Toast.LENGTH_SHORT).show();

                    Intent i = new Intent(UpdateSalary.this, ViewSalary.class);
                    startActivity(i);
                }
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbHandler.deleteSalary(bacluong1);
                Toast.makeText(UpdateSalary.this, "Xóa thành công", Toast.LENGTH_SHORT).show();

                Intent i = new Intent(UpdateSalary.this, ViewSalary.class);
                startActivity(i);
            }
        });
    }
}