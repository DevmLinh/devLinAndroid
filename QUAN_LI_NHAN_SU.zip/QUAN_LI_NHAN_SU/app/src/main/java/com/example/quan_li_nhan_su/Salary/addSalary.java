package com.example.quan_li_nhan_su.Salary;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quan_li_nhan_su.DBHandler;
import com.example.quan_li_nhan_su.Department.addDepartment;
import com.example.quan_li_nhan_su.MainActivity;
import com.example.quan_li_nhan_su.R;

public class addSalary extends AppCompatActivity {
    private EditText edtBL, edtLCB, edtHSL;
    private Button btnAdd, btnBack, btnMenu;
    private TextView tvBack;
    String bacluong,luongcd,heso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_salary);

        DBHandler db = new DBHandler(addSalary.this);

        edtBL = findViewById(R.id.idEdtMaCV);
        edtLCB = findViewById(R.id.idEdtLuongCB);
        edtHSL = findViewById(R.id.idEdtHeSo);
        btnAdd = findViewById(R.id.idBtnAddSalary);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(addSalary.this, MainActivity.class);
                startActivity(i);            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bacluong = edtBL.getText().toString();
                luongcd = edtLCB.getText().toString();
                heso = edtHSL.getText().toString();

                if (bacluong.isEmpty() || luongcd.isEmpty() || heso.isEmpty()) {
                    Toast.makeText(addSalary.this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                } else {
                    db.addSalary(bacluong, luongcd, heso);
                    Toast.makeText(addSalary.this, "Thêm thành công", Toast.LENGTH_SHORT).show();
                    clear();
                }
            }
        });
    }
    public void clear() {
        edtBL.setText("");
        edtLCB.setText("");
        edtHSL.setText("");
        edtBL.requestFocus();
    }
}
