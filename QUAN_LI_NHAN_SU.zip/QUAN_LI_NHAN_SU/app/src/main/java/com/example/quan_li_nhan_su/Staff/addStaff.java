package com.example.quan_li_nhan_su.Staff;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quan_li_nhan_su.DBHandler;
import com.example.quan_li_nhan_su.MainActivity;
import com.example.quan_li_nhan_su.R;
import com.example.quan_li_nhan_su.Salary.ViewSalary;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class addStaff extends AppCompatActivity {
    private EditText edtMANV, edtTENV, edtNOISINH, edtDIACHI, edtDIENTHOAI, edtQUEQUAN;
    private RadioGroup radioGroup;
    private RadioButton radioButton;
    private Button btnAddStaff1;
    private TextView tvBack, tvDPNgaySinh;
    private Spinner spDantoc, spMATD, spMACV, spMAPB, spBACLUONG;
    private DBHandler dbHandler;
    String manv, tennv, ngaysinh, noisinh, gioitinh, dantoc, diachi, dienthoai, quequan, matd, macv, mapb, bacluong;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_staff);

        dbHandler = new DBHandler(addStaff.this);

        edtMANV = findViewById(R.id.idEdtMaNV1);
        edtTENV = findViewById(R.id.idEdtTenNV);

        edtNOISINH = findViewById(R.id.idEdtNoiSinh);
        edtDIACHI = findViewById(R.id.idEdtDiaChi);
        edtDIENTHOAI = findViewById(R.id.idEdtSDT);
        edtQUEQUAN = findViewById(R.id.idEdtQueQuan);

        radioGroup = findViewById(R.id.idBtnGroupGioiTinh);
        btnAddStaff1 = findViewById(R.id.idBtnAddTime);

        tvBack = findViewById(R.id.idBtnBack);
        tvDPNgaySinh = findViewById(R.id.idTvDPNS);

        spDantoc = findViewById(R.id.idSpDantoc);
        spMATD = (Spinner) findViewById(R.id.idSpMaTDo);
        spMACV = (Spinner) findViewById(R.id.idSpUpdateMaCvu);
        spMAPB = (Spinner) findViewById(R.id.idSpMaPban);
        spBACLUONG = (Spinner) findViewById(R.id.idSpBacluong);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(addStaff.this, MainActivity.class);
                startActivity(i);
            }
        });

        tvDPNgaySinh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chonngay();
            }
        });

        spDantoc.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                dantoc = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spMATD.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                matd = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spMACV.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                macv = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spMAPB.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                mapb = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spBACLUONG.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                bacluong = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        loadSpinerDataDantoc();
        loadSpinerDataMaTD();
        loadSpinerDataMaCV();
        loadSpinerDataMaPB();
        loadSpinerDataBacLuong();


        btnAddStaff1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectID = radioGroup.getCheckedRadioButtonId();
                radioButton = (RadioButton) findViewById(selectID);

                manv = edtMANV.getText().toString();
                tennv = edtTENV.getText().toString();
                ngaysinh = tvDPNgaySinh.getText().toString();
                noisinh = edtNOISINH.getText().toString();
                gioitinh = radioButton.getText().toString();
                diachi = edtDIACHI.getText().toString();
                dienthoai = edtDIENTHOAI.getText().toString();
                quequan = edtQUEQUAN.getText().toString();

                Toast.makeText(addStaff.this, manv + " " + tennv + " " + ngaysinh + " " + gioitinh + " " + dantoc + " " + diachi + " " + dienthoai + " " + quequan + " ", Toast.LENGTH_SHORT).show();

                if(manv.isEmpty() || tennv.isEmpty() || ngaysinh.isEmpty() || noisinh.isEmpty() || gioitinh.isEmpty() || dantoc.isEmpty() || diachi.isEmpty() || quequan.isEmpty() || dienthoai.isEmpty()) {
                    Toast.makeText(addStaff.this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                } else {
                    dbHandler.addStaff(manv, tennv, ngaysinh, noisinh, gioitinh, dantoc, diachi, dienthoai, quequan, matd, macv, mapb, bacluong);
                    Toast.makeText(addStaff.this, "Thêm thành công", Toast.LENGTH_SHORT).show();

                    edtMANV.setText("");
                    edtTENV.setText("");
                    edtNOISINH.setText("");
                    edtDIACHI.setText("");
                    edtDIENTHOAI.setText("");
                    edtQUEQUAN.setText("");
                }
            }
        });

    }

    public void chonngay() {
        CalendarView calendarView;
        final Calendar calendar = Calendar.getInstance();
        int D = calendar.get(Calendar.DAY_OF_MONTH);
        int M = calendar.get(Calendar.MONTH);
        int Y = calendar.get(Calendar.YEAR) - 18;

        DatePickerDialog datePickerDialog = new DatePickerDialog(addStaff.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePickerView, int year, int month, int day) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
                if(calendar.get(Calendar.YEAR) - year < 18) {
                    Toast.makeText(addStaff.this, "Vui lòng nhập ngày sinh hợp lệ", Toast.LENGTH_SHORT).show();
                } else {
                    calendar.set(year, month, day);
                    tvDPNgaySinh.setText(simpleDateFormat.format(calendar.getTime()));
                }
            }
        }, Y, M, D);

        datePickerDialog.show();
    }

    public void loadSpinerDataDantoc() {
        String[] newArr = {"KINH", "BANA",	"BỐ Y",	"BRÂU",	"BRU-VÂN KIỀU", "CHĂM",	"CHƠ RO", "CHU-RU", "CHỨT", "CO", "CƠ HO", "CỜ LAO", "CƠ TU", "CỐNG", "DAO", "Ê-ĐÊ", "GIA RAI", "GIÁY",	"GIÉ-TRIÊNG", "HÀ NHÌ",	"HOA", "HRÊ", "KHÁNG", "KHMER", "KHƠ MÚ", "LA CHÍ", "LA HA", "LA HỦ", "LÀO", "LÔ LÔ", "LỰ",	"MẠ",	"MẢNG","MNÔNG",	"MÔNG",	"MƯỜNG",	"NGÁI","NÙNG",	"Ơ ĐU",	"PÀ THẺN",	"PHÙ LÁ","PU PÉO",	"RA GLAY",	"RƠ MĂM",	"SÁN CHAY","SÁN DÌU",	"SI LA",	"TÀ ÔI",	"TÀY","THÁI",	"THỔ",	"XINH MUN", "XƠ ĐĂNG", "XTIÊNG"};
//        List<String> List = new ArrayList<>();
//        List.addAll(0, newArr);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, newArr);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDantoc.setAdapter(dataAdapter);
    }

    public void loadSpinerDataMaTD() {
        String tb_name = "Trinh_Do";
        List<String> List = new ArrayList<>();
        List = dbHandler.readAllMa(tb_name);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, List);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMATD.setAdapter(dataAdapter);
    }

    // data spiner chuc vu
    public void loadSpinerDataMaCV() {
        String tb_name = "Chuc_vu";
        List<String> List = new ArrayList<>();
        List = dbHandler.readAllMa(tb_name);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, List);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMACV.setAdapter(dataAdapter);
    }

    // data spiner phong ban
    public void loadSpinerDataMaPB() {
        String tb_name = "Phong_Ban";
        List<String> List = new ArrayList<>();
        List = dbHandler.readAllMa(tb_name);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, List);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMAPB.setAdapter(dataAdapter);
    }

    // data spiner bac luong
    public void loadSpinerDataBacLuong() {
        String tb_name = "He_So_Luong";
        List<String> List = new ArrayList<>();
        List = dbHandler.readAllMa(tb_name);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, List);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spBACLUONG.setAdapter(dataAdapter);
    }

}