package com.example.quan_li_nhan_su.Time;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quan_li_nhan_su.DBHandler;
import com.example.quan_li_nhan_su.MainActivity;
import com.example.quan_li_nhan_su.R;
import com.example.quan_li_nhan_su.Salary.ViewSalary;

public class Time extends AppCompatActivity {
    private Button btnAdd, btnList;
    private DBHandler db;
    private TextView tvBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time);
        db = new DBHandler(Time.this);
        btnAdd = findViewById(R.id.btnAddTime);
        btnList = findViewById(R.id.btnListTime);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Time.this, MainActivity.class);
                startActivity(i);
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Time.this, addTime.class);
                startActivity(i);
            }
        });

        btnList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String tb_name = "Thoi_gian_nhan_chuc";
                if (db.check(tb_name)) {
                    Toast.makeText(Time.this, "Danh sách trống, vui lòng thêm dữ liệu", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(Time.this, addTime.class);
                    startActivity(i);
                } else {
                    Intent i = new Intent(Time.this, ViewTime.class);
                    startActivity(i);
                }
            }
        });
    }
}