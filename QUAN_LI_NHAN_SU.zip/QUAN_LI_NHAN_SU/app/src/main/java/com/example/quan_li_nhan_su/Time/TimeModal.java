package com.example.quan_li_nhan_su.Time;

public class TimeModal {
    private String MANV;
    private String MACV;
    private String NGAY_NC;

    public TimeModal(String manv, String macv, String tgnc) {
        this.MANV = manv;
        this.MACV = macv;
        this.NGAY_NC = tgnc;
    }

    public String getMANV() {
        return MANV;
    }

    public String getMACV() {
        return MACV;
    }

    public String getNGAY_NC() {
        return NGAY_NC;
    }

    public void setMANV(String MANV) {
        this.MANV = MANV;
    }

    public void setMACV(String MACV) {
        this.MACV = MACV;
    }

    public void setTGNC(String TGNC) {
        this.NGAY_NC = TGNC;
    }
}
