package com.example.quan_li_nhan_su.Time;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.quan_li_nhan_su.R;

import java.util.ArrayList;

public class TimeRVAdapter extends RecyclerView.Adapter<TimeRVAdapter.ViewHolder> {

    private ArrayList<TimeModal> ModalArrayList;
    private Context context;

    public TimeRVAdapter(ArrayList<TimeModal> ModalArrayList, Context context) {
        this.ModalArrayList = ModalArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.time_rv_item ,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TimeModal modal = ModalArrayList.get(position);
        holder.Manv.setText("Mã nhân viên: " + modal.getMANV());
        holder.Macv.setText("Mã chức vụ: " + modal.getMACV());
        holder.NgayNc.setText("Ngày nhận chức: " + modal.getNGAY_NC());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(context, UpdateTime.class);

                // below we are passing all our values.
                i.putExtra("Manv", modal.getMANV());
                i.putExtra("Macv", modal.getMACV());
                i.putExtra("NgayNc", modal.getNGAY_NC());

                // starting our activity.
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() { return ModalArrayList.size(); }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView Manv, Macv, NgayNc;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            Manv = itemView.findViewById(R.id.tvMaNVTime);
            Macv = itemView.findViewById(R.id.tvMaCVTime);
            NgayNc = itemView.findViewById(R.id.tvNgayNC);
        }
    }
}
