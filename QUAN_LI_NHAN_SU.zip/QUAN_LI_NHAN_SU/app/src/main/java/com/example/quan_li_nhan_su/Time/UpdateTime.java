package com.example.quan_li_nhan_su.Time;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quan_li_nhan_su.DBHandler;
import com.example.quan_li_nhan_su.MainActivity;
import com.example.quan_li_nhan_su.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class UpdateTime extends AppCompatActivity {
    private Spinner spMANV, spMACV;
    private TextView tvDpNgayNC, tvBack;
    private Button btnUpdate, btnDelete;
    private DBHandler dbHandler;
    private String manv, macv, ngaync, manv1, macv1;
    private Boolean isSelectManv = false, isSelectMacv = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_time);

        dbHandler = new DBHandler(UpdateTime.this);

        spMANV = findViewById(R.id.idSpUpdateManvView);
        spMACV = findViewById(R.id.idSpUpdateMacvView);
        tvDpNgayNC = findViewById(R.id.idTvUpdateDpNgayNC);
        btnUpdate = findViewById(R.id.idBtnUpdateTime);
        btnDelete = findViewById(R.id.idBtnDeleteTime);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(UpdateTime.this, MainActivity.class);
                startActivity(i);
            }
        });

        Intent intent = this.getIntent();

        manv1 = intent.getStringExtra("Manv");
        macv1 = intent.getStringExtra("Macv");
        ngaync = intent.getStringExtra("NgayNc");

        tvDpNgayNC.setText("" + ngaync);

        tvDpNgayNC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chonngay();
            }
        });

        spMANV.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if(!isSelectManv) {
                    for (int j = 1; j <= parent.getCount(); j++) {
                        if (manv1.equals(parent.getItemAtPosition(j - 1).toString())) {
                            parent.setSelection(j - 1);
                            isSelectManv = true;
                            break;
                        }
                    }
                }
                manv = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spMACV.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(!isSelectMacv) {
                    for (int j = 1; j <= parent.getCount(); j++) {
                        if (macv1.equals(parent.getItemAtPosition(j - 1).toString())) {
                            parent.setSelection(j - 1);
                            isSelectMacv = true;
                            break;
                        }
                    }
                }
                macv = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        loadSpinerDataMaNV();
        loadSpinerDataMaCV();

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ngaync = tvDpNgayNC.getText().toString();

                if(manv.isEmpty() || macv.isEmpty() || ngaync.isEmpty()) {
                    Toast.makeText(UpdateTime.this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                } else {
                    dbHandler.updateTime(manv1, macv1,  manv, macv, ngaync);
                    Toast.makeText(UpdateTime.this, "Cập nhật thành công", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(UpdateTime.this, ViewTime.class);
                    startActivity(i);
                }
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbHandler.deleteTime(manv1, macv1);
                Toast.makeText(UpdateTime.this, "Xóa thành công", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(UpdateTime.this, ViewTime.class);
                startActivity(i);
            }
        });




    }

    public void chonngay() {
        CalendarView calendarView;
        final Calendar calendar = Calendar.getInstance();
        int D = calendar.get(Calendar.DAY_OF_MONTH);
        int M = calendar.get(Calendar.MONTH);
        int Y = calendar.get(Calendar.YEAR) - 18;

        DatePickerDialog datePickerDialog = new DatePickerDialog(UpdateTime.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePickerView, int year, int month, int day) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
                if(calendar.get(Calendar.YEAR) - year < 18) {
                    Toast.makeText(UpdateTime.this, "Vui lòng nhập ngày sinh hợp lệ", Toast.LENGTH_SHORT).show();
                } else {
                    calendar.set(year, month, day);
                    tvDpNgayNC.setText(simpleDateFormat.format(calendar.getTime()));
                }
            }
        }, Y, M, D);

        datePickerDialog.show();
    }

    public void loadSpinerDataMaNV() {
        String tb_name = "Nhan_vien";
        List<String> List = new ArrayList<>();
        List = dbHandler.readAllMa(tb_name);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, List);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMANV.setAdapter(dataAdapter);
    }

    public void loadSpinerDataMaCV() {
        String tb_name = "Chuc_vu";
        List<String> List = new ArrayList<>();
        List = dbHandler.readAllMa(tb_name);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, List);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMACV.setAdapter(dataAdapter);
    }
}