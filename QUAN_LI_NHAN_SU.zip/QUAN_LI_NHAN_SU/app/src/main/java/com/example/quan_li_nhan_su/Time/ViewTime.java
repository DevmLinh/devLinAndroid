package com.example.quan_li_nhan_su.Time;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.quan_li_nhan_su.DBHandler;
import com.example.quan_li_nhan_su.MainActivity;
import com.example.quan_li_nhan_su.R;

import java.util.ArrayList;
import java.util.List;

public class ViewTime extends AppCompatActivity {
    private ArrayList<TimeModal> ModalArrayList;
    private DBHandler dbHandler;
    private TimeRVAdapter RVAdapter;
    private RecyclerView recyclerView;
    private Spinner spManv, spMacv;
    private TextView tvBack;
    private String manv = "001", macv = "GĐ";

    @Override
    protected void  onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_time);
        ModalArrayList = new ArrayList<>();
        dbHandler = new DBHandler(ViewTime.this);

        spManv = findViewById(R.id.idSpManvView);
        spMacv = findViewById(R.id.idSpMacvView);

        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ViewTime.this, MainActivity.class);
                startActivity(i);
            }
        });


        spManv.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                manv = parent.getItemAtPosition(position).toString();

                ModalArrayList = dbHandler.readTime(manv, macv);

                RVAdapter = new TimeRVAdapter(ModalArrayList, ViewTime.this);
                recyclerView = findViewById(R.id.idRVTime);

                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(ViewTime.this, RecyclerView.VERTICAL,false);
                recyclerView.setLayoutManager(linearLayoutManager);

                recyclerView.setAdapter(RVAdapter);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spMacv.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                macv = parent.getItemAtPosition(position).toString();

                ModalArrayList = dbHandler.readTime(manv, macv);

                RVAdapter = new TimeRVAdapter(ModalArrayList, ViewTime.this);
                recyclerView = findViewById(R.id.idRVTime);

                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(ViewTime.this, RecyclerView.VERTICAL,false);
                recyclerView.setLayoutManager(linearLayoutManager);

                recyclerView.setAdapter(RVAdapter);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        loadSpinerDataMaNV();
        loadSpinerDataMaCV();


    }

    public void loadSpinerDataMaNV() {
        String tb_name = "Nhan_vien";
        List<String> List = new ArrayList<>();
        List = dbHandler.readAllMa(tb_name);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, List);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spManv.setAdapter(dataAdapter);
    }

    public void loadSpinerDataMaCV() {
        String tb_name = "Chuc_vu";
        List<String> List = new ArrayList<>();
        List = dbHandler.readAllMa(tb_name);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, List);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMacv.setAdapter(dataAdapter);
    }
}
