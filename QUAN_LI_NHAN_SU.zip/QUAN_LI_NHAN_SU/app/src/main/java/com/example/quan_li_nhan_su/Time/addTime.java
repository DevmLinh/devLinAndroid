package com.example.quan_li_nhan_su.Time;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quan_li_nhan_su.DBHandler;
import com.example.quan_li_nhan_su.MainActivity;
import com.example.quan_li_nhan_su.R;
import com.example.quan_li_nhan_su.Salary.ViewSalary;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class addTime extends AppCompatActivity {
    private Spinner spMANV, spMACV;
    private TextView tvDpNgayNC, tvBack;
    private Button btnAdd;
    private DBHandler dbHandler;
    private String manv, macv, ngaync;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_time);

        dbHandler = new DBHandler(addTime.this);

        spMANV = findViewById(R.id.idSpManvView);
        spMACV = findViewById(R.id.idSpMacvView);
        tvDpNgayNC = findViewById(R.id.idTvDpNgayNC);
        btnAdd = findViewById(R.id.idBtnAddTime);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(addTime.this, MainActivity.class);
                startActivity(i);
            }
        });

        tvDpNgayNC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chonngay();
            }
        });

        spMANV.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                manv = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spMACV.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                macv = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        loadSpinerDataMaNV();
        loadSpinerDataMaCV();

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ngaync = tvDpNgayNC.getText().toString();

                if(manv.isEmpty() || macv.isEmpty() || ngaync.isEmpty()) {
                    Toast.makeText(addTime.this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                } else {
                    dbHandler.addTime(manv, macv, ngaync);
                    Toast.makeText(addTime.this, "Thêm thành công", Toast.LENGTH_SHORT).show();

                }
            }
        });




    }

    public void chonngay() {
        CalendarView calendarView;
        final Calendar calendar = Calendar.getInstance();
        int D = calendar.get(Calendar.DAY_OF_MONTH);
        int M = calendar.get(Calendar.MONTH);
        int Y = calendar.get(Calendar.YEAR) - 18;

        DatePickerDialog datePickerDialog = new DatePickerDialog(addTime.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePickerView, int year, int month, int day) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
                if(calendar.get(Calendar.YEAR) - year < 18) {
                    Toast.makeText(addTime.this, "Vui lòng nhập ngày sinh hợp lệ", Toast.LENGTH_SHORT).show();
                } else {
                    calendar.set(year, month, day);
                    tvDpNgayNC.setText(simpleDateFormat.format(calendar.getTime()));
                }
            }
        }, Y, M, D);

        datePickerDialog.show();
    }

    public void loadSpinerDataMaNV() {
        String tb_name = "Nhan_vien";
        List<String> List = new ArrayList<>();
        List = dbHandler.readAllMa(tb_name);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, List);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMANV.setAdapter(dataAdapter);
    }

    public void loadSpinerDataMaCV() {
        String tb_name = "Chuc_vu";
        List<String> List = new ArrayList<>();
        List = dbHandler.readAllMa(tb_name);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, List);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMACV.setAdapter(dataAdapter);
    }
}