package com.example.quan_li_nhan_su.level;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quan_li_nhan_su.DBHandler;
import com.example.quan_li_nhan_su.Department.addDepartment;
import com.example.quan_li_nhan_su.MainActivity;
import com.example.quan_li_nhan_su.R;

public class Level extends AppCompatActivity {
    private Button btnAdd, btnList;
    private DBHandler db;
    private TextView tvBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level);

        btnAdd = findViewById(R.id.btnAddLevel);
        btnList = findViewById(R.id.btnListLevel);
        DBHandler db = new DBHandler(Level.this);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Level.this, MainActivity.class);
                startActivity(i);
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Level.this,addLevel.class);
                startActivity(i);
            }
        });

        btnList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!db.checkDP()) {
                    Intent i = new Intent(Level.this, viewLevel.class);
                    startActivity(i);

                } else {
                    Toast.makeText(Level.this, "Danh sách rỗng, vui lòng nhập thông tin", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(Level.this, addLevel.class);
                    startActivity(i);
                }
            }
        });
    }
}
