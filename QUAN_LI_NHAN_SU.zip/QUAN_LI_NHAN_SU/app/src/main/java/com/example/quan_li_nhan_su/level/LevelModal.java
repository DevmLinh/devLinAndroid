package com.example.quan_li_nhan_su.level;

public class LevelModal {
    private String MA_TD;
    private String TEN_TD;
    private String CHUYEN_NGANH;

    public LevelModal(String matd, String tentd, String chuyennganh) {
        this.MA_TD = matd;
        this.TEN_TD = tentd;
        this.CHUYEN_NGANH = chuyennganh;
    }

    public String getMA_TD() {
        return MA_TD;
    }

    public void setMA_TD(String MA_TD) {
        this.MA_TD = MA_TD;
    }

    public String getTEN_TD() {
        return TEN_TD;
    }

    public void setTEN_TD(String TEN_TD) {
        this.TEN_TD = TEN_TD;
    }

    public String getCHUYEN_NGANH() {
        return CHUYEN_NGANH;
    }

    public void setCHUYEN_NGANH(String CHUYEN_NGANH) {
        this.CHUYEN_NGANH = CHUYEN_NGANH;
    }

}
