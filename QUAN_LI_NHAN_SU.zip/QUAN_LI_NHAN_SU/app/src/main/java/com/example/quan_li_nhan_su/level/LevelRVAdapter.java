package com.example.quan_li_nhan_su.level;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.quan_li_nhan_su.Department.UpdateDepartment;
import com.example.quan_li_nhan_su.R;

import java.util.ArrayList;

public class LevelRVAdapter extends RecyclerView.Adapter<LevelRVAdapter.ViewHolder> {

    private ArrayList<LevelModal> ModalArrayList;
    private Context context;

    public LevelRVAdapter(ArrayList<LevelModal> ModalArrayList,Context context){
        this.ModalArrayList = ModalArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.level_rv_item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        LevelModal modal = ModalArrayList.get(position);
        holder.matd.setText("Mã trình độ: " + modal.getMA_TD());
        holder.tentd.setText("Tên trình độ: " + modal.getTEN_TD());
        holder.chuyennganh.setText("Chuyên ngành: " + modal.getCHUYEN_NGANH());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, updateLevel.class);

                // below we are passing all our values.
                i.putExtra("MaTD", modal.getMA_TD());
                i.putExtra("TenTD", modal.getTEN_TD());
                i.putExtra("CHUYENNGANH", modal.getCHUYEN_NGANH());

                // starting our activity.
                context.startActivity(i);
            }
        });
    }


    @Override
    public int getItemCount() { return ModalArrayList.size(); }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView matd, tentd, chuyennganh;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            matd = itemView.findViewById(R.id.tvMaTD);
            tentd = itemView.findViewById(R.id.tvTenTD);
            chuyennganh = itemView.findViewById(R.id.tvCN);
        }
    }
}


