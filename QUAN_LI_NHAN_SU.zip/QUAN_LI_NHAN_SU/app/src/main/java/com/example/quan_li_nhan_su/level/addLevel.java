package com.example.quan_li_nhan_su.level;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quan_li_nhan_su.DBHandler;
import com.example.quan_li_nhan_su.MainActivity;
import com.example.quan_li_nhan_su.R;

public class addLevel extends AppCompatActivity {
    private EditText edtMaTD, edtTenTD, edtCN;
    private Button btnAdd, btnBack, btnMenu;
    private TextView tvBack;
    String matd, tentd, chuyennganh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_level);

        DBHandler db = new DBHandler(addLevel.this);

        edtMaTD = findViewById(R.id.idEdtMaTD);
        edtTenTD = findViewById(R.id.idEdtTenTD);
        edtCN = findViewById(R.id.idEdtCN);
        btnAdd = findViewById(R.id.idBtnAddLevel);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(addLevel.this, MainActivity.class);
                startActivity(i);
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                matd = edtMaTD.getText().toString();
                tentd = edtTenTD.getText().toString();
                chuyennganh = edtCN.getText().toString();

                if (matd.isEmpty() || tentd.isEmpty() || chuyennganh.isEmpty()) {
                    Toast.makeText(addLevel.this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                } else {
                    db.addLevel(matd, tentd, chuyennganh);
                    Toast.makeText(addLevel.this, "Thêm thành công", Toast.LENGTH_SHORT).show();
                    clear();
                }
            }
        });
    }
    public void clear() {
        edtMaTD.setText("");
        edtTenTD.setText("");
        edtCN.setText("");
        edtMaTD.requestFocus();
    }
}
