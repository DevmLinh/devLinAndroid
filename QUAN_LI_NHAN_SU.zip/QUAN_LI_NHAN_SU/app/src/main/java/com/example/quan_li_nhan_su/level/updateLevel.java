package com.example.quan_li_nhan_su.level;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quan_li_nhan_su.DBHandler;
import com.example.quan_li_nhan_su.Department.addDepartment;
import com.example.quan_li_nhan_su.MainActivity;
import com.example.quan_li_nhan_su.R;

public class updateLevel extends AppCompatActivity {
    private EditText edtMaTD, edtTenTD, edtCN;
    private Button btnEdit, btnDelete;
    private DBHandler dbHandler;
    private TextView tvBack;
    String matd, tentd, chuyennganh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_level);

        dbHandler = new DBHandler(updateLevel.this);
        edtMaTD = findViewById(R.id.idEdtUpdateMaTD);
        edtTenTD = findViewById(R.id.idEdtUpdateTenTD);
        edtCN = findViewById(R.id.idEdtUpdateCN);
        btnDelete = findViewById(R.id.idBtnDeleteLevel);
        btnEdit = findViewById(R.id.idBtnUpdateLevel);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(updateLevel.this, MainActivity.class);
                startActivity(i);
            }
        });

        Intent i = this.getIntent();

        matd = i.getStringExtra("MaTD");
        tentd = i.getStringExtra("TenTD");
        chuyennganh = i.getStringExtra("CHUYENNGANH");

        edtMaTD.setText(" " + matd);
        edtTenTD.setText(" " + tentd);
        edtCN.setText(" " + chuyennganh);

        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtMaTD.getText().toString().isEmpty() || edtTenTD.getText().toString().isEmpty() || edtCN.getText().toString().isEmpty()) {
                    Toast.makeText(updateLevel.this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                } else {
                    dbHandler.updateLevel(matd, edtMaTD.getText().toString(),edtTenTD.getText().toString(),edtCN.getText().toString());
                    Toast.makeText(updateLevel.this, "Cập nhật thành công", Toast.LENGTH_SHORT).show();

                    Intent i = new Intent(updateLevel.this,viewLevel.class);
                    startActivity(i);
                }
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbHandler.deleteLevel(matd);

                Toast.makeText(updateLevel.this, "Xóa thành công", Toast.LENGTH_SHORT).show();

                if (!dbHandler.checkLV()) {
                    Intent i = new Intent(updateLevel.this,viewLevel.class);
                    startActivity(i);
                } else {
                    Intent i = new Intent(updateLevel.this,Level.class);
                    Toast.makeText(updateLevel.this, "Danh sách rỗng", Toast.LENGTH_SHORT).show();
                    startActivity(i);
                }
            }
        });

    }
}
