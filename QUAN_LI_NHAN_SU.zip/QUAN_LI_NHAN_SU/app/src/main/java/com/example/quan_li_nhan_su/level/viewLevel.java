package com.example.quan_li_nhan_su.level;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.example.quan_li_nhan_su.DBHandler;
import com.example.quan_li_nhan_su.Department.addDepartment;
import com.example.quan_li_nhan_su.MainActivity;
import com.example.quan_li_nhan_su.R;

import java.util.ArrayList;

public class viewLevel extends AppCompatActivity {
    private ArrayList<LevelModal> ModalArrayList;
    private DBHandler dbHandler;
    private LevelRVAdapter RVAdapter;
    private RecyclerView recyclerView;
    private TextView tvBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_level);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(viewLevel.this, MainActivity.class);
                startActivity(i);
            }
        });

        ModalArrayList = new ArrayList<>();
        dbHandler = new DBHandler(viewLevel.this);
        ModalArrayList = dbHandler.readLevel();
        RVAdapter = new LevelRVAdapter(ModalArrayList,viewLevel.this);
        recyclerView = findViewById(R.id.idRVLevel);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(viewLevel.this, RecyclerView.VERTICAL,false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(RVAdapter);
    }
}
