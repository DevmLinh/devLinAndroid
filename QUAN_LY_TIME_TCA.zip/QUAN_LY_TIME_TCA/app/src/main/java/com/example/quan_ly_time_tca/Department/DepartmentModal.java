package com.example.quan_ly_time_tca.Department;

public class DepartmentModal {
    private String MA_PB;
    private String TEN_PB;
    private String DIA_CHI;
    private String SDT;

    public String getMA_PB() {
        return MA_PB;
    }

    public String getTEN_PB() {
        return TEN_PB;
    }

    public String getDIA_CHI() {
        return DIA_CHI;
    }

    public String getSDT() {
        return SDT;
    }

    public void setMA_PB(String MA_PB) {
        this.MA_PB = MA_PB;
    }

    public void setTEN_PB(String TEN_PB) {
        this.TEN_PB = TEN_PB;
    }

    public void setDIA_CHI(String DIA_CHI) {
        this.DIA_CHI = DIA_CHI;
    }

    public void setSDT(String SDT) {
        this.SDT = SDT;
    }

    public DepartmentModal(String mapb, String tenpb, String diachi, String sdt) {
        this.MA_PB = mapb;
        this.TEN_PB = tenpb;
        this.DIA_CHI = diachi;
        this.SDT = sdt;
    }
}
