package com.example.quan_ly_time_tca.Department;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.quan_ly_time_tca.R;

import java.util.ArrayList;

public class DepartmentRVAdapter extends RecyclerView.Adapter<DepartmentRVAdapter.ViewHolder> {

    private ArrayList<DepartmentModal> ModalArrayList;
    private Context context;

    public DepartmentRVAdapter(ArrayList<DepartmentModal> ModalArrayList, Context context) {
        this.ModalArrayList = ModalArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.department_rv_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DepartmentModal modal = ModalArrayList.get(position);
        holder.mapb.setText("Mã phòng ban: " + modal.getMA_PB());
        holder.tenpb.setText("Tên phòng ban: " +modal.getTEN_PB());
        holder.diachi.setText("Địa chỉ: " +modal.getDIA_CHI());
        holder.sdt.setText("Số điện thoại: " +modal.getSDT());


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(context, UpdateDepartment.class);

                // below we are passing all our values.
                i.putExtra("Mapb", modal.getMA_PB());
                i.putExtra("Tenpb", modal.getTEN_PB());
                i.putExtra("Diachi", modal.getDIA_CHI());
                i.putExtra("Sdt", modal.getSDT());

                // starting our activity.
                context.startActivity(i);
            }
        });

    }

    @Override
    public int getItemCount() {
        return ModalArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView mapb, tenpb, diachi, sdt;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            mapb = itemView.findViewById(R.id.tvMaPB);
            tenpb = itemView.findViewById(R.id.tvTenPB);
            diachi = itemView.findViewById(R.id.tvDiaChiPB);
            sdt = itemView.findViewById(R.id.tvSdtPB);
        }
    }
}
