package com.example.quan_ly_time_tca.Department;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quan_ly_time_tca.DBHandler;
import com.example.quan_ly_time_tca.MainActivity;
import com.example.quan_ly_time_tca.R;

public class UpdateDepartment extends AppCompatActivity {
    private EditText edtMaPB, edtTenPB, edtDiaChi, edtSdt;
    private Button btnUpdate, btnDelete;
    private DBHandler dbHandler;
    String mapb, tenpb, diachi, sdt;
    private TextView tvBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_department);

        dbHandler =  new DBHandler(UpdateDepartment.this);

        edtMaPB = findViewById(R.id.idEdtUpdateMaPB);
        edtTenPB = findViewById(R.id.idEdtUpdateTenPB);
        edtDiaChi = findViewById(R.id.idEdtUpdateDiaChiPB);
        edtSdt = findViewById(R.id.idEdtUpdateSdtPB);
        btnUpdate = findViewById(R.id.idBtnUpdateDepartment);
        btnDelete = findViewById(R.id.idBtnDeleteDepartment);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(UpdateDepartment.this, MainActivity.class);
                startActivity(i);
            }
        });

        Intent intent = this.getIntent();

        mapb = intent.getStringExtra("Mapb");
        tenpb = intent.getStringExtra("Tenpb");
        diachi = intent.getStringExtra("Diachi");
        sdt = intent.getStringExtra("Sdt");

        edtMaPB.setText(" " + mapb);
        edtTenPB.setText(" " + tenpb);
        edtDiaChi.setText(" " + diachi);
        edtSdt.setText(" " + sdt);

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtMaPB.getText().toString().isEmpty() || edtTenPB.getText().toString().isEmpty() || edtDiaChi.getText().toString().isEmpty() || edtSdt.getText().toString().isEmpty()) {
                    Toast.makeText(UpdateDepartment.this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                } else {
                    dbHandler.updateDepartment(mapb, edtMaPB.getText().toString(), edtTenPB.getText().toString(), edtDiaChi.getText().toString(), edtSdt.getText().toString());
                    Toast.makeText(UpdateDepartment.this, "Cập nhật thành công", Toast.LENGTH_SHORT).show();

                    Intent i = new Intent(UpdateDepartment.this, ViewDepartment.class);
                    startActivity(i);
                }
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbHandler.deleteCourse(mapb);

                Toast.makeText(UpdateDepartment.this, "Xóa thành công", Toast.LENGTH_SHORT).show();

                if (!dbHandler.checkDP()) {
                    Intent i = new Intent(UpdateDepartment.this, ViewDepartment.class);
                    startActivity(i);
                } else {
                    Intent i = new Intent(UpdateDepartment.this, ViewDepartment.class);
                    Toast.makeText(UpdateDepartment.this, "Danh sách rỗng", Toast.LENGTH_SHORT).show();
                    startActivity(i);
                }

            }
        });
    }
}