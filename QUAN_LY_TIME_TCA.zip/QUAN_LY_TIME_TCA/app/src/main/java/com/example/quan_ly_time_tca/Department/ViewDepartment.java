package com.example.quan_ly_time_tca.Department;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.example.quan_ly_time_tca.DBHandler;
import com.example.quan_ly_time_tca.MainActivity;
import com.example.quan_ly_time_tca.R;

import java.util.ArrayList;

public class ViewDepartment extends AppCompatActivity {

    private ArrayList<DepartmentModal> ModalArrayList;
    private DBHandler dbHandler;
    private DepartmentRVAdapter RVAdapter;
    private RecyclerView recyclerView;
    private TextView tvBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_department);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ViewDepartment.this, MainActivity.class);
                startActivity(i);
            }
        });

        ModalArrayList = new ArrayList<>();
        dbHandler = new DBHandler(ViewDepartment.this);

        ModalArrayList = dbHandler.readDepartment();

        RVAdapter = new DepartmentRVAdapter(ModalArrayList, ViewDepartment.this);
        recyclerView = findViewById(R.id.idRVDepartment);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(ViewDepartment.this, RecyclerView.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);

        recyclerView.setAdapter(RVAdapter);
    }
}
