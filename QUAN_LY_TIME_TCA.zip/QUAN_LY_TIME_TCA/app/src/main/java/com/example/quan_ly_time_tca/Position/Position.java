package com.example.quan_ly_time_tca.Position;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quan_ly_time_tca.DBHandler;
import com.example.quan_ly_time_tca.MainActivity;
import com.example.quan_ly_time_tca.R;

public class Position extends AppCompatActivity {
    private Button btnAdd, btnList;
    private DBHandler db;
    private TextView tvBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_position);
        db = new DBHandler(Position.this);
        btnAdd = findViewById(R.id.btnAddPosition);
        btnList = findViewById(R.id.btnListPosition);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Position.this, MainActivity.class);
                startActivity(i);
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Position.this, addPosition.class);
                startActivity(i);
            }
        });

        btnList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String tb_name = "Chuc_vu";
                if (db.check(tb_name)) {
                    Toast.makeText(Position.this, "Danh sách trống, vui lòng thêm dữ liệu", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(Position.this, addPosition.class);
                    startActivity(i);
                } else {
                    Intent i = new Intent(Position.this, ViewPosition.class);
                    startActivity(i);
                }
            }
        });
    }
}