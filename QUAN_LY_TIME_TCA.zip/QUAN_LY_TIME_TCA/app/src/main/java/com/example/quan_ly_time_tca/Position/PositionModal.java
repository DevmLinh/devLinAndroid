package com.example.quan_ly_time_tca.Position;

public class PositionModal {
    private String Ma_cv;
    private String Ten_cv;
    private String He_so_pc;

    public String getMa_cv() {
        return Ma_cv;
    }

    public String getTen_cv() {
        return Ten_cv;
    }

    public String getHe_so_pc() {
        return He_so_pc;
    }

    public void setMa_cv(String ma_cv) {
        Ma_cv = ma_cv;
    }

    public void setTen_cv(String ten_cv) {
        Ten_cv = ten_cv;
    }

    public void setHe_so_pc(String he_so_pc) {
        He_so_pc = he_so_pc;
    }

    public PositionModal(String macv, String tencv, String hspc) {
        this.Ma_cv = macv;
        this.Ten_cv = tencv;
        this.He_so_pc = hspc;
    }
}
