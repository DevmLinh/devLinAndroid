package com.example.quan_ly_time_tca.Position;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quan_ly_time_tca.DBHandler;
import com.example.quan_ly_time_tca.MainActivity;
import com.example.quan_ly_time_tca.R;

public class UpdatePosition extends AppCompatActivity {
    private EditText edtMACV, edtTENCV, edtHSPC;
    private Button btnUpdate, btnDelete, btnBack, btnMenu;
    private DBHandler dbHandler;
    private String macv, tencv, hesopc;
    private TextView tvBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_position);

        dbHandler = new DBHandler(UpdatePosition.this);

        edtMACV = findViewById(R.id.idEdtUpdateMaCV);
        edtTENCV = findViewById(R.id.idEdtUpdateTenCV);
        edtHSPC = findViewById(R.id.idEdtUpdateHeSoPC);
        btnUpdate = findViewById(R.id.idBtnUpdatePosition);
        btnDelete = findViewById(R.id.idBtnDeletePosition);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(UpdatePosition.this, MainActivity.class);
                startActivity(i);
            }
        });

        Intent intent = this.getIntent();

        macv = intent.getStringExtra("Macv");
        tencv = intent.getStringExtra("Tencv");
        hesopc = intent.getStringExtra("Hesopc");

        edtMACV.setText(" " + macv);
        edtTENCV.setText(" " + tencv);
        edtHSPC.setText(" " + hesopc);

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtMACV.getText().toString().isEmpty() || edtTENCV.getText().toString().isEmpty() || edtHSPC.getText().toString().isEmpty()) {
                    Toast.makeText(UpdatePosition.this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                } else {
                    dbHandler.updatePosition(macv, edtMACV.getText().toString(), edtTENCV.getText().toString(), edtHSPC.getText().toString());
                    Toast.makeText(UpdatePosition.this, "Cập nhật thành công", Toast.LENGTH_SHORT).show();

                    Intent i = new Intent(UpdatePosition.this, ViewPosition.class);
                    startActivity(i);
                }
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbHandler.deletePosition(macv);
                Toast.makeText(UpdatePosition.this, "Xóa thành công", Toast.LENGTH_SHORT).show();

                Intent i = new Intent(UpdatePosition.this, ViewPosition.class);
                startActivity(i);
            }
        });
    }
}