package com.example.quan_ly_time_tca.Salary;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quan_ly_time_tca.DBHandler;
import com.example.quan_ly_time_tca.MainActivity;
import com.example.quan_ly_time_tca.R;

public class Salary extends AppCompatActivity {
    private Button btnAdd, btnList;
    private DBHandler db;
    private TextView tvBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_salary);
        db = new DBHandler(Salary.this);
        btnAdd = findViewById(R.id.btnAddSalary);
        btnList = findViewById(R.id.btnListSalary);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Salary.this, MainActivity.class);
                startActivity(i);
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Salary.this,addSalary.class);
                startActivity(i);
            }
        });

        btnList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String tb_name = "He_So_Luong";
                if (db.check(tb_name)) {
                    Toast.makeText(Salary.this, "Danh sách trống, vui lòng thêm dữ liệu", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(Salary.this, addSalary.class);
                    startActivity(i);
                } else {
                    Intent i = new Intent(Salary.this, ViewSalary.class);
                    startActivity(i);
                }

            }
        });
    }
}