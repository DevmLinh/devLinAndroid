package com.example.quan_ly_time_tca.Salary;

public class SalaryModal {
    private String BAC_LUONG;
    private String LUONG_CB;
    private String HE_SO;

    public SalaryModal(String bacluong, String luongcb, String heso) {
        this.BAC_LUONG = bacluong;
        this.LUONG_CB = luongcb;
        this.HE_SO = heso;
    }

    public String getBAC_LUONG() {
        return BAC_LUONG;
    }

    public void setBAC_LUONG(String BAC_LUONG) {
        this.BAC_LUONG = BAC_LUONG;
    }

    public String getLUONG_CB() {
        return LUONG_CB;
    }

    public void setLUONG_CB(String LUONG_CB) {
        this.LUONG_CB = LUONG_CB;
    }

    public String getHE_SO() {
        return HE_SO;
    }

    public void setHE_SO(String HE_SO) {
        this.HE_SO = HE_SO;
    }
}
