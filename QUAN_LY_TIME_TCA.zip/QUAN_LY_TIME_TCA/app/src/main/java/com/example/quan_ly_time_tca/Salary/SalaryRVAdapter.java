package com.example.quan_ly_time_tca.Salary;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.quan_ly_time_tca.R;

import java.util.ArrayList;

public class SalaryRVAdapter extends RecyclerView.Adapter<SalaryRVAdapter.ViewHolder> {

    private ArrayList<SalaryModal> ModalArrayList;
    private Context context;

    public SalaryRVAdapter(ArrayList<SalaryModal> ModalArrayList, Context context) {
        this.ModalArrayList = ModalArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.salary_rv_item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        SalaryModal modal = ModalArrayList.get(position);
        holder.bacluong.setText("Bậc lương: " + modal.getBAC_LUONG());
        holder.luongcb.setText("Lương cơ bản: " + modal.getLUONG_CB());
        holder.heso.setText("Hệ số lương: " + modal.getHE_SO());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(context, UpdateSalary.class);

                // below we are passing all our values.
                i.putExtra("bacluong", modal.getBAC_LUONG());
                i.putExtra("luongcb", modal.getLUONG_CB());
                i.putExtra("hsluong", modal.getHE_SO());

                // starting our activity.
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() { return ModalArrayList.size(); }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView bacluong, luongcb, heso;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            bacluong = itemView.findViewById(R.id.tvBacLuong);
            luongcb = itemView.findViewById(R.id.tvLuongCB);
            heso = itemView.findViewById(R.id.tvHeSo);
        }
    }
}
