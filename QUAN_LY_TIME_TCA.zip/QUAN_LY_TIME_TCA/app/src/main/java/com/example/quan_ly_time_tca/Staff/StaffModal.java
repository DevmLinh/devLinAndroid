package com.example.quan_ly_time_tca.Staff;

public class StaffModal {
    private String MANV;
    private String TENNV;
    private String NGAYSINH;
    private String NOISINH;
    private String GIOITINH;
    private String DANTOC;
    private String DIACHI;
    private String DIENTHOAI;
    private String QUEQUAN;
    private String MATCA;
    private String MACV;
    private String MAPB;
    private String BACLUONG;

    public StaffModal(String manv, String tennv, String ngaysinh, String noisinh, String gioitinh, String dantoc, String diachi, String dienthoai, String quequan, String tangca, String chucvu, String phongban, String bacluong) {
        this.MANV = manv;
        this.TENNV = tennv;
        this.NGAYSINH = ngaysinh;
        this.NOISINH = noisinh;
        this.GIOITINH = gioitinh;
        this.DANTOC = dantoc;
        this.DIACHI = diachi;
        this.DIENTHOAI = dienthoai;
        this.QUEQUAN = quequan;
        this.MATCA = tangca;
        this.MACV = chucvu;
        this.MAPB = phongban;
        this.BACLUONG = bacluong;
    }

    public String getMANV() {
        return MANV;
    }

    public String getTENNV() {
        return TENNV;
    }

    public String getNGAYSINH() {
        return NGAYSINH;
    }

    public String getNOISINH() {
        return NOISINH;
    }

    public String getGIOITINH() {
        return GIOITINH;
    }

    public String getDANTOC() {
        return DANTOC;
    }

    public String getDIACHI() {
        return DIACHI;
    }

    public String getDIENTHOAI() {
        return DIENTHOAI;
    }

    public String getQUEQUAN() {
        return QUEQUAN;
    }

    public String getMATCA() {
        return MATCA;
    }

    public String getMACV() {
        return MACV;
    }

    public String getMAPB() {
        return MAPB;
    }

    public String getBACLUONG() {
        return BACLUONG;
    }

    public void setMANV(String MANV) {
        this.MANV = MANV;
    }

    public void setTENNV(String TENNV) {
        this.TENNV = TENNV;
    }

    public void setNGAYSINH(String NGAYSINH) {
        this.NGAYSINH = NGAYSINH;
    }

    public void setNOISINH(String NOISINH) {
        this.NOISINH = NOISINH;
    }

    public void setGIOITINH(String GIOITINH) {
        this.GIOITINH = GIOITINH;
    }

    public void setDANTOC(String DANTOC) {
        this.DANTOC = DANTOC;
    }

    public void setDIACHI(String DIACHI) {
        this.DIACHI = DIACHI;
    }

    public void setDIENTHOAI(String DIENTHOAI) {
        this.DIENTHOAI = DIENTHOAI;
    }

    public void setQUEQUAN(String QUEQUAN) {
        this.QUEQUAN = QUEQUAN;
    }

    public void setMATD(String MATCA) {
        this.MATCA = MATCA;
    }

    public void setMACV(String MACV) {
        this.MACV = MACV;
    }

    public void setMAPB(String MAPB) {
        this.MAPB = MAPB;
    }

    public void setBACLUONG(String BACLUONG) {
        this.BACLUONG = BACLUONG;
    }
}
