package com.example.quan_ly_time_tca.Staff;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.quan_ly_time_tca.R;

import java.util.ArrayList;

public class StaffRVAdapter extends RecyclerView.Adapter<StaffRVAdapter.ViewHolder> {

    private ArrayList<StaffModal> ModalArrayList;
    private Context context;

    public StaffRVAdapter(ArrayList<StaffModal> ModalArrayList, Context context) {
        this.ModalArrayList = ModalArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.staff_rv_item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        StaffModal modal = ModalArrayList.get(position);
        holder.manv.setText("Mã nhân viên: " + modal.getMANV());
        holder.tennv.setText("Tên nhân viên: " + modal.getTENNV());
        holder.ngaysinh.setText("Ngày sinh: " + modal.getNGAYSINH());
        holder.noisinh.setText("Nơi sinh: " + modal.getNOISINH());
        holder.gioitinh.setText("Giới tính: " + modal.getGIOITINH());
        holder.dantoc.setText("Dân tộc: " + modal.getDANTOC());
        holder.diachi.setText("Địa chỉ: " + modal.getDIACHI());
        holder.dienthoai.setText("Điện thoại: " + modal.getDIENTHOAI());
        holder.quequan.setText("Quê quán: " + modal.getQUEQUAN());
        holder.matca.setText("Mã tăng ca: " + modal.getMATCA());
        holder.macv.setText("Mã chức vụ: " + modal.getMACV());
        holder.mapb.setText("Mã phòng ban: " + modal.getMAPB());
        holder.bacluong.setText("Bậc lương: " + modal.getBACLUONG());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(context, UpdateStaff.class);

                // below we are passing all our values.
                i.putExtra("manv", modal.getMANV());
                i.putExtra("tennv", modal.getTENNV());
                i.putExtra("ngaysinh", modal.getNGAYSINH());
                i.putExtra("noisinh", modal.getNOISINH());
                i.putExtra("gioitinh", modal.getGIOITINH());
                i.putExtra("dantoc", modal.getDANTOC());
                i.putExtra("diachi", modal.getDIACHI());
                i.putExtra("dienthoai", modal.getDIENTHOAI());
                i.putExtra("quequan", modal.getQUEQUAN());
                i.putExtra("matca", modal.getMATCA());
                i.putExtra("macv", modal.getMACV());
                i.putExtra("mapb", modal.getMAPB());
                i.putExtra("bacluong", modal.getBACLUONG());

                // starting our activity.
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() { return ModalArrayList.size(); }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView manv, tennv, ngaysinh, noisinh, gioitinh, dantoc, diachi, dienthoai, quequan, matca, macv, mapb, bacluong;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            manv = itemView.findViewById(R.id.tvMANV);
            tennv = itemView.findViewById(R.id.tvTENNV);
            ngaysinh = itemView.findViewById(R.id.tvNGAYSINH);
            noisinh = itemView.findViewById(R.id.tvNOISINH);
            gioitinh = itemView.findViewById(R.id.tvGIOITINH);
            dantoc = itemView.findViewById(R.id.tvDANTOC);
            diachi = itemView.findViewById(R.id.tvDIACHI);
            dienthoai = itemView.findViewById(R.id.tvSDT);
            quequan = itemView.findViewById(R.id.tvQUEQUAN);
            matca = itemView.findViewById(R.id.tvMATCA_NV);
            macv = itemView.findViewById(R.id.tvMaCV_NV);
            mapb = itemView.findViewById(R.id.tvMaPB_NV);
            bacluong = itemView.findViewById(R.id.tvBacLuong_NV);

        }
    }
}
