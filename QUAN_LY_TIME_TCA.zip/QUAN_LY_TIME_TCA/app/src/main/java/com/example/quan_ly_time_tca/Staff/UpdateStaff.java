package com.example.quan_ly_time_tca.Staff;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quan_ly_time_tca.DBHandler;
import com.example.quan_ly_time_tca.MainActivity;
import com.example.quan_ly_time_tca.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class UpdateStaff extends AppCompatActivity {
    private EditText edtMANV, edtTENV, edtNOISINH, edtDIACHI, edtDIENTHOAI, edtQUEQUAN;
    private RadioGroup radioGroup;
    private RadioButton radioButton;
    private Button btnUpdate, btnDelete;
    private TextView tvBack, tvDPNgaySinh;
    private Spinner spDantoc, spMATCA, spMACV, spMAPB, spBACLUONG;
    private DBHandler dbHandler;
    String manv, tennv, ngaysinh, noisinh, gioitinh, dantoc, diachi, dienthoai, quequan, matd, macv, mapb, bacluong, dantoc1, matca1, macv1, mapb1, bacluong1;
    Boolean isSelectDantoc = false, isSelectMatca = false, isSelectMacv = false, isSelectMapb = false, isSelectBacluong = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_staff);

        dbHandler = new DBHandler(UpdateStaff.this);

        edtMANV = findViewById(R.id.idEdtUpdateMaNV1);
        edtTENV = findViewById(R.id.idEdtUpdateTenNV);

        edtNOISINH = findViewById(R.id.idEdtUpdateNoiSinh);
        edtDIACHI = findViewById(R.id.idEdtUpdateDiaChi);
        edtDIENTHOAI = findViewById(R.id.idEdtUpdateSDT);
        edtQUEQUAN = findViewById(R.id.idEdtUpdateQueQuan);

        radioGroup = findViewById(R.id.idBtnGroupUpdateGioiTinh);
        btnUpdate = findViewById(R.id.idBtnUpdateStaff);
        btnDelete = findViewById(R.id.idBtnDeleteStaff);

        tvDPNgaySinh = findViewById(R.id.idTvUpdateDPNS);
        tvBack = findViewById(R.id.idBtnBack);

        spDantoc = findViewById(R.id.idSpUpdateDantoc);
        spMATCA = findViewById(R.id.idSpUpdateMaTCa);
        spMACV = (Spinner) findViewById(R.id.idSpUpdateMaCvu);
        spMAPB = (Spinner) findViewById(R.id.idSpUpdateMaPban);
        spBACLUONG = (Spinner) findViewById(R.id.idSpUpdateBacluong);

        Intent intent = this.getIntent();

        manv = intent.getStringExtra("manv");
        tennv = intent.getStringExtra("tennv");
        ngaysinh = intent.getStringExtra("ngaysinh");
        noisinh = intent.getStringExtra("noisinh");
        gioitinh = intent.getStringExtra("gioitinh");
        dantoc1 = intent.getStringExtra("dantoc");
        diachi = intent.getStringExtra("diachi");
        dienthoai = intent.getStringExtra("dienthoai");
        quequan = intent.getStringExtra("quequan");
        matca1 = intent.getStringExtra("matca");
        macv1 = intent.getStringExtra("macv");
        mapb1 = intent.getStringExtra("mapb");
        bacluong1 = intent.getStringExtra("bacluong");

        edtMANV.setText("" + manv);
        edtTENV.setText("" + tennv);
        edtNOISINH.setText("" + noisinh);
        edtDIACHI.setText("" + diachi);
        edtDIENTHOAI.setText("" + dienthoai);
        edtQUEQUAN.setText("" + quequan);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(UpdateStaff.this, MainActivity.class);
                startActivity(i);
            }
        });

        tvDPNgaySinh.setText("" + ngaysinh);

        if(gioitinh.equals("Nam")) {
            radioButton = findViewById(R.id.idBtnMale);
        } else {
            radioButton = findViewById(R.id.idBtnFemale);
        }

        radioButton.setChecked(true);

        tvDPNgaySinh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chonngay();
            }
        });

        spDantoc.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if(!isSelectDantoc) {
                    for (int j = 1; j <= parent.getCount(); j++) {
                        if (dantoc1.equals(parent.getItemAtPosition(j - 1).toString())) {
                            parent.setSelection(j - 1);
                            isSelectDantoc = true;
                            break;
                        }
                    }
                }
                dantoc = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        spMATCA.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if(!isSelectMatca) {
                    for (int j = 1; j <= parent.getCount(); j++) {
                        if (matca1.equals(parent.getItemAtPosition(j - 1).toString())) {
                            parent.setSelection(j - 1);
                            isSelectMatca = true;
                            break;
                        }
                    }
                }
                matd = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spMACV.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(!isSelectMacv) {
                    for (int j = 1; j <= parent.getCount(); j++) {
                        if (macv1.equals(parent.getItemAtPosition(j - 1).toString())) {
                            parent.setSelection(j - 1);
                            isSelectMacv = true;
                            break;
                        }
                    }
                }
                macv = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spMAPB.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(!isSelectMapb) {
                    for (int j = 1; j <= parent.getCount(); j++) {
                        if (mapb1.equals(parent.getItemAtPosition(j - 1).toString())) {
                            parent.setSelection(j - 1);
                            isSelectMapb = true;
                            break;
                        }
                    }
                }
                mapb = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spBACLUONG.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(!isSelectBacluong) {
                    for (int j = 1; j <= parent.getCount(); j++) {
                        if (bacluong1.equals(parent.getItemAtPosition(j - 1).toString())) {
                            parent.setSelection(j - 1);
                            isSelectBacluong = true;
                            break;
                        }
                    }
                }
                bacluong = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        loadSpinerDataDantoc();
        loadSpinerDataMaTD();
        loadSpinerDataMaCV();
        loadSpinerDataMaPB();
        loadSpinerDataBacLuong();


        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int selectID = radioGroup.getCheckedRadioButtonId();
                radioButton = (RadioButton) findViewById(selectID);

                if(edtMANV.getText().toString().isEmpty() || edtTENV.getText().toString().isEmpty() || edtNOISINH.getText().toString().isEmpty() || edtDIACHI.getText().toString().isEmpty() || edtDIENTHOAI.getText().toString().isEmpty() || edtQUEQUAN.getText().toString().isEmpty()) {
                    Toast.makeText(UpdateStaff.this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                } else {
                    try{
                         dbHandler.updateStaff(manv, edtMANV.getText().toString(), edtTENV.getText().toString(), tvDPNgaySinh.getText().toString(), edtNOISINH.getText().toString(), radioButton.getText().toString(), dantoc, edtDIACHI.getText().toString(), edtDIENTHOAI.getText().toString(), edtQUEQUAN.getText().toString(), matd, macv, mapb, bacluong);
                         Toast.makeText(UpdateStaff.this, "Thêm thành công", Toast.LENGTH_SHORT).show();

                         Intent i = new Intent(UpdateStaff.this, ViewStaff.class);
                         startActivity(i);

                    } catch(Exception error) {
                        Toast.makeText(UpdateStaff.this, "Mã nhân viên trùng với nhân viên khác, vui lòng nhập lại", Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(UpdateStaff.this, ViewStaff.class);
                        startActivity(i);
                    }
                }
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbHandler.deleteStaff(manv);
                Toast.makeText(UpdateStaff.this, "Xóa thành công", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(UpdateStaff.this, ViewStaff.class);
                startActivity(i);
            }
        });


    }

    public void chonngay() {
        CalendarView calendarView;
        final Calendar calendar = Calendar.getInstance();
        int D = calendar.get(Calendar.DAY_OF_MONTH);
        int M = calendar.get(Calendar.MONTH);
        int Y = calendar.get(Calendar.YEAR) - 18;

        DatePickerDialog datePickerDialog = new DatePickerDialog(UpdateStaff.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePickerView, int year, int month, int day) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
                if(calendar.get(Calendar.YEAR) - year < 18) {
                    Toast.makeText(UpdateStaff.this, "Vui lòng nhập ngày sinh hợp lệ", Toast.LENGTH_SHORT).show();
                } else {
                    calendar.set(year, month, day);
                    tvDPNgaySinh.setText(simpleDateFormat.format(calendar.getTime()));
                }
            }
        }, Y, M, D);

        datePickerDialog.show();
    }

    public void loadSpinerDataDantoc() {
        String[] newArr = {"KINH", "BANA",	"BỐ Y",	"BRÂU",	"BRU-VÂN KIỀU", "CHĂM",	"CHƠ RO", "CHU-RU", "CHỨT", "CO", "CƠ HO", "CỜ LAO", "CƠ TU", "CỐNG", "DAO", "Ê-ĐÊ", "GIA RAI", "GIÁY",	"GIÉ-TRIÊNG", "HÀ NHÌ",	"HOA", "HRÊ", "KHÁNG", "KHMER", "KHƠ MÚ", "LA CHÍ", "LA HA", "LA HỦ", "LÀO", "LÔ LÔ", "LỰ",	"MẠ",	"MẢNG","MNÔNG",	"MÔNG",	"MƯỜNG",	"NGÁI","NÙNG",	"Ơ ĐU",	"PÀ THẺN",	"PHÙ LÁ","PU PÉO",	"RA GLAY",	"RƠ MĂM",	"SÁN CHAY","SÁN DÌU",	"SI LA",	"TÀ ÔI",	"TÀY","THÁI",	"THỔ",	"XINH MUN", "XƠ ĐĂNG", "XTIÊNG"};

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, newArr);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDantoc.setAdapter(dataAdapter);
    }

    public void loadSpinerDataMaTD() {
        String tb_name = "Tang_ca";
        List<String> List = new ArrayList<>();
        List = dbHandler.readAllMa(tb_name);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, List);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMATCA.setAdapter(dataAdapter);
    }

    // data spiner chuc vu
    public void loadSpinerDataMaCV() {
        String tb_name = "Chuc_vu";
        List<String> List = new ArrayList<>();
        List = dbHandler.readAllMa(tb_name);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, List);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMACV.setAdapter(dataAdapter);
    }

    // data spiner phong ban
    public void loadSpinerDataMaPB() {
        String tb_name = "Phong_Ban";
        List<String> List = new ArrayList<>();
        List = dbHandler.readAllMa(tb_name);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, List);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMAPB.setAdapter(dataAdapter);
    }

    // data spiner bac luong
    public void loadSpinerDataBacLuong() {
        String tb_name = "He_So_Luong";
        List<String> List = new ArrayList<>();
        List = dbHandler.readAllMa(tb_name);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, List);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spBACLUONG.setAdapter(dataAdapter);
    }

}