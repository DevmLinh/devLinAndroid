package com.example.quan_ly_time_tca.Staff;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.quan_ly_time_tca.DBHandler;
import com.example.quan_ly_time_tca.MainActivity;
import com.example.quan_ly_time_tca.R;

import java.util.ArrayList;
import java.util.List;

public class ViewStaff extends AppCompatActivity {
    private ArrayList<StaffModal> ModalArrayList;
    private DBHandler dbHandler;
    private StaffRVAdapter RVAdapter;
    private RecyclerView recyclerView;
    private List<String> Mapb = new ArrayList<>();
    private Spinner spMaPbList;
    List<String> List = new ArrayList<>();
    String mapb = "";
    private TextView tvBack;

    @Override
    protected void  onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_staff);

        ModalArrayList = new ArrayList<>();
        dbHandler = new DBHandler(ViewStaff.this);
        spMaPbList = findViewById(R.id.idSpMaPBList);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ViewStaff.this, MainActivity.class);
                startActivity(i);
            }
        });

        spMaPbList.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                mapb = parent.getItemAtPosition(position).toString();

                ModalArrayList = dbHandler.readStaff(mapb);

                RVAdapter = new StaffRVAdapter(ModalArrayList, ViewStaff.this);
                recyclerView = findViewById(R.id.idRVStaff);

                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(ViewStaff.this, RecyclerView.VERTICAL,false);
                recyclerView.setLayoutManager(linearLayoutManager);

                recyclerView.setAdapter(RVAdapter);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        loadSpinerDataMaPB();

    }

    // data spiner phong ban
    public void loadSpinerDataMaPB() {
        String tb_name = "Phong_Ban";
        List = dbHandler.readAllMa(tb_name);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, List);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMaPbList.setAdapter(dataAdapter);
    }
}
