package com.example.quan_ly_time_tca.tca;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quan_ly_time_tca.DBHandler;
import com.example.quan_ly_time_tca.MainActivity;
import com.example.quan_ly_time_tca.R;

public class TCa extends AppCompatActivity {
    private Button btnAdd, btnList;
    private DBHandler db;
    private TextView tvBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tca);

        btnAdd = findViewById(R.id.btnAddTCa);
        btnList = findViewById(R.id.btnListTCa);
        DBHandler db = new DBHandler(TCa.this);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(TCa.this, MainActivity.class);
                startActivity(i);
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(TCa.this,addTca.class);
                startActivity(i);
            }
        });

        btnList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!db.checkTCA()) {
                    Intent i = new Intent(TCa.this, viewTCa.class);
                    startActivity(i);

                } else {
                    Toast.makeText(TCa.this, "Danh sách rỗng, vui lòng nhập thông tin", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(TCa.this, addTca.class);
                    startActivity(i);
                }
            }
        });
    }
}
