package com.example.quan_ly_time_tca.tca;

public class TCaModal {
    private String MA_TCA;
    private String TEN_TCA;
    private String TIME_TCA;

    public TCaModal(String matca, String tentca, String timetca) {
        this.MA_TCA = matca;
        this.TEN_TCA = tentca;
        this.TIME_TCA = timetca;
    }

    public String getMA_TCa() {
        return MA_TCA;
    }

    public void setMA_TCA(String MA_TCA) {
        this.MA_TCA = MA_TCA;
    }

    public String getTEN_CVIEC() {
        return TEN_TCA;
    }

    public void setTEN_CVIEC(String TEN_TCA) {
        this.TEN_TCA = TEN_TCA;
    }

    public String getTIME_TCA() {
        return TIME_TCA;
    }

    public void setTIME_TCA(String TIME_TCA) {
        this.TIME_TCA = TIME_TCA;
    }

}
