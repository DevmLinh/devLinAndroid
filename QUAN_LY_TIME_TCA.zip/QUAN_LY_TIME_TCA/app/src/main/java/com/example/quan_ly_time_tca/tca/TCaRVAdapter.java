package com.example.quan_ly_time_tca.tca;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.quan_ly_time_tca.R;

import java.util.ArrayList;

public class TCaRVAdapter extends RecyclerView.Adapter<TCaRVAdapter.ViewHolder> {

    private ArrayList<TCaModal> ModalArrayList;
    private Context context;

    public TCaRVAdapter(ArrayList<TCaModal> ModalArrayList,Context context){
        this.ModalArrayList = ModalArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.tca_rv_item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TCaModal modal = ModalArrayList.get(position);
        holder.matca.setText("Mã tăng ca: " + modal.getMA_TCa());
        holder.chitietcviec.setText("Chi tiết công việc: " + modal.getTEN_CVIEC());
        holder.timetca.setText("Thời gian làm việc: " + modal.getTIME_TCA());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, updateTCa.class);

                // below we are passing all our values.
                i.putExtra("MaTCa", modal.getMA_TCa());
                i.putExtra("ChiTietCViec", modal.getTEN_CVIEC());
                i.putExtra("TimeTCa", modal.getTIME_TCA());

                // starting our activity.
                context.startActivity(i);
            }
        });
    }


    @Override
    public int getItemCount() { return ModalArrayList.size(); }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView matca, chitietcviec, timetca;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            matca = itemView.findViewById(R.id.tvMaTCa);
            chitietcviec = itemView.findViewById(R.id.tvChiTietCViec);
            timetca = itemView.findViewById(R.id.tvTimeCViec);
        }
    }
}


