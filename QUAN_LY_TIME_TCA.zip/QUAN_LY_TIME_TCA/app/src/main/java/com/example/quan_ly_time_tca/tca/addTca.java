package com.example.quan_ly_time_tca.tca;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.quan_ly_time_tca.DBHandler;
import com.example.quan_ly_time_tca.MainActivity;
import com.example.quan_ly_time_tca.R;

import java.text.DateFormat;
import java.util.Calendar;

public class addTca extends AppCompatActivity {
    private EditText edtMaTCa, edtChiTietCViec;
    private Button btnAdd, btnDate, btnTimeStart;
    private TextView tvBack,tvDateAndTime;
    String matca, tencviec, timetca;

    DateFormat fmtDateAndTime = DateFormat.getDateTimeInstance();
    Calendar myCalendar = Calendar.getInstance();
    DatePickerDialog.OnDateSetListener d = new DatePickerDialog.OnDateSetListener()
    {
        public void onDateSet(DatePicker view,
                              int year, int monthOfYear, int dayOfMonth) {
            myCalendar.set(Calendar.YEAR, year);
            myCalendar.set(Calendar.MONTH, monthOfYear);
            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            updateLabel();
        }
    };
    TimePickerDialog.OnTimeSetListener t = new TimePickerDialog.OnTimeSetListener()
    {
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            myCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
            myCalendar.set(Calendar.MINUTE, minute);
            updateLabel();
        }
    };

    private void updateLabel() {
        tvDateAndTime.setText(fmtDateAndTime.format(myCalendar.getTime()));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_tca);

        DBHandler db = new DBHandler(addTca.this);

        edtMaTCa = findViewById(R.id.idEdtMaTCa);
        edtChiTietCViec = findViewById(R.id.idEdtTenCViec);

        tvDateAndTime = (TextView) findViewById(R.id.idEdtTimeTCa);
        btnDate = (Button) findViewById(R.id.btnDate);
        btnTimeStart = (Button) findViewById(R.id.btnTimeStart);

        btnAdd = findViewById(R.id.idBtnAddLevel);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(addTca.this, MainActivity.class);
                startActivity(i);
            }
        });


        btnDate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                new DatePickerDialog(addTca.this, d,
                        myCalendar.get(Calendar.YEAR),
                        myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });


        btnTimeStart.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                new TimePickerDialog(addTca.this, t,
                        myCalendar.get(Calendar.HOUR_OF_DAY),
                        myCalendar.get(Calendar.MINUTE), true).show();
            }
        });

        updateLabel();
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                matca = edtMaTCa.getText().toString();
                tencviec = edtChiTietCViec.getText().toString();
                timetca = tvDateAndTime.getText().toString();

                if (matca.isEmpty() || tencviec.isEmpty() || timetca.isEmpty()) {
                    Toast.makeText(addTca.this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                } else {
                    db.addTca(matca, tencviec, timetca);
                    Toast.makeText(addTca.this, "Thêm thành công", Toast.LENGTH_SHORT).show();
                    clear();
                }
            }
        });
    }
    public void clear() {
        edtMaTCa.setText("");
        edtChiTietCViec.setText("");
        edtMaTCa.requestFocus();
    }
}
