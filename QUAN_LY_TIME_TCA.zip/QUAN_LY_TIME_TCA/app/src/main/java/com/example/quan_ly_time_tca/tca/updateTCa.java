package com.example.quan_ly_time_tca.tca;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quan_ly_time_tca.DBHandler;
import com.example.quan_ly_time_tca.MainActivity;
import com.example.quan_ly_time_tca.R;

public class updateTCa extends AppCompatActivity {
    private EditText edtMaTCa, edtTenCV;
    private Button btnEdit, btnDelete;
    private DBHandler dbHandler;
    private TextView tvBack, tvTimeTca;
    String matca, tentca, timetca;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_tca);

        dbHandler = new DBHandler(updateTCa.this);
        edtMaTCa = findViewById(R.id.idEdtUpdateMaTCa);
        edtTenCV = findViewById(R.id.idEdtUpdateChiTietCViec);
        tvTimeTca= findViewById(R.id.idEdtupdateTimeTCa);
        btnDelete = findViewById(R.id.idBtnDeleteLevel);
        btnEdit = findViewById(R.id.idBtnUpdateTca);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(updateTCa.this, MainActivity.class);
                startActivity(i);
            }
        });

        Intent i = this.getIntent();

        matca = i.getStringExtra("MaTCa");
        tentca = i.getStringExtra("ChiTietCViec");
        timetca = i.getStringExtra("TimeTCa");

        edtMaTCa.setText(" " + matca);
        edtTenCV.setText(" " + tentca);
        tvTimeTca.setText(" " + timetca);

        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtMaTCa.getText().toString().isEmpty() || edtTenCV.getText().toString().isEmpty() || tvTimeTca.getText().toString().isEmpty()) {
                    Toast.makeText(updateTCa.this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                } else {
                    dbHandler.updateTca(matca, edtMaTCa.getText().toString(),edtTenCV.getText().toString(),tvTimeTca.getText().toString());
                    Toast.makeText(updateTCa.this, "Cập nhật thành công", Toast.LENGTH_SHORT).show();

                    Intent i = new Intent(updateTCa.this,viewTCa.class);
                    startActivity(i);
                }
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbHandler.deleteTca(matca);

                Toast.makeText(updateTCa.this, "Xóa thành công", Toast.LENGTH_SHORT).show();

                if (!dbHandler.checkTCA()) {
                    Intent i = new Intent(updateTCa.this,viewTCa.class);
                    startActivity(i);
                } else {
                    Intent i = new Intent(updateTCa.this, TCa.class);
                    Toast.makeText(updateTCa.this, "Danh sách rỗng", Toast.LENGTH_SHORT).show();
                    startActivity(i);
                }
            }
        });

    }
}
