package com.example.quan_ly_time_tca.tca;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.example.quan_ly_time_tca.DBHandler;
import com.example.quan_ly_time_tca.MainActivity;
import com.example.quan_ly_time_tca.R;

import java.util.ArrayList;

public class viewTCa extends AppCompatActivity {
    private ArrayList<TCaModal> ModalArrayList;
    private DBHandler dbHandler;
    private TCaRVAdapter RVAdapter;
    private RecyclerView recyclerView;
    private TextView tvBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_tca);
        tvBack = findViewById(R.id.idBtnBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(viewTCa.this, MainActivity.class);
                startActivity(i);
            }
        });

        ModalArrayList = new ArrayList<>();
        dbHandler = new DBHandler(viewTCa.this);
        ModalArrayList = dbHandler.readTca();
        RVAdapter = new TCaRVAdapter(ModalArrayList,viewTCa.this);
        recyclerView = findViewById(R.id.idRVLevel);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(viewTCa.this, RecyclerView.VERTICAL,false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(RVAdapter);
    }
}
